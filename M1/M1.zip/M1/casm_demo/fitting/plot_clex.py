from casm.project import Project, Selection, write_eci
import matplotlib.pyplot as plt

# construct a 'Selection'
proj = Project()
sel = Selection(proj, 'CALCULATED', all=False)

# query results into a pandas.DataFrame
comp = 'atom_frac(Ge)'
Ef = 'formation_energy'
clex = 'clex(formation_energy)'
hull_dist = 'hull_dist(CALCULATED,atom_frac)'
sel.query([comp, Ef, clex, hull_dist])

# get convex hull configurations, sorted for nice plotting
df = sel.data.sort_values([comp])
hull_tol = 1e-6
df_hull = df[df[hull_dist] < hull_tol]

# plot formation energies with convex hull
sc1 = plt.scatter(sel.data[comp], sel.data[Ef],  marker='o', label='DFT')
sc2 = plt.scatter(sel.data[comp], sel.data[clex],  marker='x', c='red', label='Cluster expansion')
plt.plot(df_hull[comp], df_hull[Ef], 'b.-')
plt.xlabel(comp)
plt.ylabel('Formation energy (eV/unit cell)')
plt.xlim([0.,1.])
plt.legend()
plt.show()
