%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% File: read_node_data.m
%
% Purpose:  Read dislocation nodal data from ParaDiS restart data file
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function read_node_data(fname)

disp('This function is not working yet!');
disp('Need to wait for Seokwoo to give us the latest file!');
