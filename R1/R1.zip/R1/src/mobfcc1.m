function [vn,fn] = mobfcc1(fseg,rn,links,connectivity,nodelist,conlist)
%mobility law function (model: FCC1)
%FCC1: velocity linear to force but remain orthogonal to glide plane
% v=f/L/B    (B = Bedge = Bscrew)
% if nodelist and conlist are empty then vn is the length of rn otherwise 
% vn is the length of nodelist

%include modifications for the specific case of frank read source
%nodes are moving towards its relatively farther neighbor

global Bscrew Bedge Beclimb Bline

if Bscrew~=Bedge
    disp('Bscrew has to be the same as Bedge in mobfcc1');
    return
end

eps=1e-12;

L1=size(nodelist,1);
if L1==0
    L1=size(rn,1);
    nodelist=linspace(1,L1,L1)';
    [L2,L3]=size(connectivity);
    conlist=zeros(L2,(L3-1)/2+1);
    conlist(:,1)=connectivity(:,1);
    for i=1:L2
        connumb=conlist(i,1);
        conlist(i,2:connumb+1)=linspace(1,connumb,connumb);
    end
end
%
for n=1:L1
    n0=nodelist(n);
    numNbrs=conlist(n,1);
    nv=zeros(numNbrs,3);
    rt=zeros(numNbrs,3);
    fn(n,:)=zeros(1,3);
    L=0;    
    for i=1:numNbrs
        ii=conlist(n,i+1);                                                                      % connectionid for this connection
        linkid=connectivity(n0,2*ii);
        posinlink=connectivity(n0,2*ii+1);
        n1=links(linkid,3-posinlink);
        %
        %added for the specific case of F-R source
        if numNbrs == 2
            if i == 1
                n_fr1 = n1;
            elseif i == 2
                n_fr2 = n1;
            end
        end
        %
        rt=rn(n1,1:3)-rn(n0,1:3);                                                               
        % calculate the length of the link and its tangent line direction
        Lni=norm(rt); 
        L = L + Lni;
        if Lni>0
            fsegn0 =fseg(linkid,3*(posinlink-1)+[1:3]);
            fn(n,:)=fn(n,:)+fsegn0; % nodeid for the node that n0 is connected to
            nv(i,:)=links(linkid,6:8);
        end    
        %ii=conlist(n,i+1);
        %n1=links(connectivity(n0,2*ii),3-connectivity(n0,2*ii+1));
        %fn(n,:)=fn(n,:)+fseg(connectivity(n0,2*ii),3*(connectivity(n0,2*ii+1)-1)+[1:3]);
        %nv(i,:)=links(connectivity(n0,2*ii),6:8);
        %rt(i,:)=rn(n1,1:3)-rn(n0,1:3);
        %L=L+norm(rt(i,:));
    end
    vn(n,:)=fn(n,:);
    L=L/2;
    
    vn(n,:)=vn(n,:) ./ L ./ Bscrew; %(active in mobfcc1)
    
    %orthogonalize vn to all gilde plane normal vectors
    for i=1:numNbrs
        for j=1:i-1,
            nv(i,:)=nv(i,:)-dot(nv(i,:),nv(j,:))*nv(j,:);
        end
        if(norm(nv(i,:))>eps)
            nv(i,:)=nv(i,:)/norm(nv(i,:));
        else
            nv(i,:)=0;
        end
    end
    %
    for i=1:numNbrs
        vn(n,:)=vn(n,:)-dot(vn(n,:),nv(i,:))*nv(i,:);
    end
    %vn(n,2) = 0;
    %
    %modified for the specific case of frank read source
    if numNbrs == 2
        x1 = rn(n_fr1,1:3);
        x2 = rn(n_fr2,1:3);
        x0 = rn(n0,1:3);
        t_minus = (x2-x1)/norm(x2-x1);
        t_plus = (x1-x0)+(x2-x0);
        %define velocity normal direction
        %compute v_normal
        t3 = cross(x1-x0,x2-x0);
        if norm(t3)~=0
            t3 =t3/norm(t3);
        end
        %normal velocity
        t_normal = cross(t3,t_minus);
        v_normal = dot(vn(n,:),t_normal)*t_normal;
        %
        %tangent velocity
        %independent from v_normal
        v_mag = 1/1000; %dt0 = 1e3 and 1e7
        v_tangent = v_mag*sign(dot(t_plus, t_minus))*t_minus;
        %sum up
        vn(n,:) = v_normal + v_tangent; 
        end
    %%
    %           
end

%nonlinear mobility law (relativistic effect)
%c=10;
%for n0=1:nnode,
%    fac=1./sqrt(1+dot(vn(n0,:),vn(n0,:))/c^2);
%    vn(n0,:)=vn(n0,:)*fac;
%end
