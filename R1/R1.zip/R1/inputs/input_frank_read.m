%Frank-Read source
close all
clear all
clc
global Bscrew Bedge Beclimb Bline

b = 0.5*[1 1 1];
n = [-1 1 0];

rn    = [ 1000   1000  1000  7;
		 -1000  -1000 -1000  7;
			0    0     0     0];
links = [1 3 b n;
		 3 2 b n];

MU = 1;
NU = 0.305;
maxconnections=8;
lmax = 1200;
lmin =  900;
areamin=lmin*lmin*sin(60/180*pi)*0.5; 
areamax=20*areamin;
a=lmin/sqrt(3)*0.5;
Ec = MU/(4*pi)*log(a/0.1);
totalsteps=150;
dt0=1e7;  
mobility='mobbcc0';
%Drag (Mobility) parameters
Bscrew=1e0;
Bedge=1e0;
Beclimb=1e2;
Bline=1.0e-4*min(Bscrew,Bedge);

integrator='int_trapezoid';
rann = 0.5*a;       
rntol = 0.5*rann;    
doremesh=1;
docollision=1;
doseparation=1;
plotfreq=1;       
plim=15000;         



for i=1:3
    for j=1:3
         str(i,j) = b(i)/norm(b)*n(j)/norm(n) + ...
                    b(j)/norm(b)*n(i)/norm(n);
    end
end

appliedstress =1e-3*str; 
viewangle=[90 0];
printfreq=1;      
printnode=3;
rmax=100;





dd3d
