clear all 
close all 
clc

global Bscrew Bedge Beclimb Bline

theta =pi*30/180;
delta=(4*sqrt(3)*cos(theta))^2-4*6*(3*cos(theta)^2-1);
y1=(4*sqrt(3)*cos(theta)+sqrt(24)*sin(theta))/12;
x1=-2*y1+sqrt(3)*cos(theta);
z1=y1;


x2=(4*sqrt(3)*cos(theta)+sqrt(24)*sin(theta))/12;
y2=-2*x2+sqrt(3)*cos(theta);
z2=x2;

alpha=pi*30/180;
x3=(4*sqrt(3)*cos(alpha)+sqrt(24)*sin(alpha))/12;
z3=-2*x3+sqrt(3)*cos(alpha);
y3=x3;

L1=1000;


rmax  = 100;

b1=[-1 1 1]./2;
b2=[1 -1 1]./2;
b3=[1 1 -1]./2;
  
n1=[0 1 -1]./sqrt(2);
n2=[1 0 -1]./sqrt(2);
n3=[1 -1 0]./sqrt(2);



point1=[x1 y1 z1].*L1;
point2=[0 0 0];
point3=[x2 y2 z2].*L1;
point4=[-x1 -y1 -z1].*L1;
point5=-[x2 y2 z2].*L1;
point6=[x3 y3 z3].*L1;
point7=[-x3 -y3 -z3].*L1;

rn=[point1 7;
    point2 0;
    point3 7;
    point4 7;
    point5 7;
    point6 7;
    point7 7;];

rn

links=[4 2 b1 n1;
       2 1 b1 n1;
       5 2 b2 n2;
       2 3 b2 n2;
       7 2 b3 n3;
       2 6 b3 n3;];
   
links

maxconnections=8;
lmax =  400;
lmin =  300;

a=lmin/sqrt(6);
MU = 1.3e11;
NU = 0.309; % for BCC Mo
Ec = MU/(4*pi)*log(a/0.1);
totalsteps=20;
areamin=lmin*lmin*sin(60/180*pi)*0.5; % minimum discretization area
areamax=20*areamin; % maximum discretization area
dt0=1e10;           %maximum time step


plim = L1;
appliedstress = zeros(3,3);
viewangle=[45 -45];
plotfreq=5;       %plot nodes every how many steps
printfreq=1;      %print out information every how many steps
printnode=3;

mobility='moblinear';
Bscrew=10;
Bedge=10;
Beclimb=100;
Bline=1.0e-4*min(Bscrew,Bedge);

integrator='int_trapezoid';
rann = 10;       %annihilation distance (capture radius)
rntol = 2*rann;      % on Tom's suggestion

doremesh =1;
docollision=1;
doseparation=1;
elasticinteraction = 1;
dofuzzy = 0;



dd3d

