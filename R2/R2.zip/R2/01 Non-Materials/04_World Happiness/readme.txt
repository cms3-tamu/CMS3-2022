SVM hyperparameter tuning gives almost 1 R^2
For 2015 data