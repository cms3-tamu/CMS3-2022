SVM hyperparameter tuning gives almost 1 R^2
