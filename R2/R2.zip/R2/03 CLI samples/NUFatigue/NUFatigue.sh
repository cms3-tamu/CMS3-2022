#!/bin/bash

# Initialize conda within the script
# Please customize based on your own setting
#
# >>> conda initialize >>>
# !! Contents within this block are managed by 'conda init' !!
__conda_setup="$('$HOME/opt/anaconda3/bin/conda' 'shell.bash' 'hook' 2> /dev/null)"
if [ $? -eq 0 ]; then
    eval "$__conda_setup"
else
    if [ -f "$HOME/opt/anaconda3/etc/profile.d/conda.sh" ]; then
        . "$HOME/opt/anaconda3/etc/profile.d/conda.sh"
    else
        export PATH="$HOME/opt/anaconda3/bin:$PATH"
    fi
fi
unset __conda_setup
# <<< conda initialize <<<

# Launch ASCENDS conda environment
conda activate ascends

# The location of ASCENDS 
ASCENDS_dir=${HOME}/ASCENDS

# Working directory to save all the output file
# Correlation analysis, trained ML models, etc.
#WORK_DIR=${PWD}

# Input data file
DATAFILE=2193-9772-3-8-s1.csv

# Target property
TARGET=Fatigue

# Columns to ignore. Usually ID
IGNORE_COL="ID"

# Algorithms: MIC or PCC
FEAT_SEL=MIC

# Number of top ranking features
FEAT_NUM=25

# Algorithm: RF, LR, BR, SVM, NN, and NET
ML_ALGO=SVM

# Hyperparameter Tuning: True or False
TUNE=True

# Save auto tune
SAVE_TUNE=True

# Scaler


# The very first run
function run {
python3 ${ASCENDS_dir}/train.py r ./${DATAFILE} \
$2 ${TARGET} \
--ignore_col ${IGNORE_COL} \
--feature_selection ${FEAT_SEL} \
--num_of_feature ${FEAT_NUM} \
--model_type $1 \
--save_corr_chart True \
--save_corr_report True \
--save_test_chart True \
--save_test_csv True \
--auto_tune ${TUNE} \
--save_auto_tune ${SAVE_TUNE}
}

# Models to train
# Algorithm: RF, LR, BR, SVM, NN, and NET
MODELS="RF SVM BR"
# Training number
TRAIN_NUM=5

# Create individual directory
for i in $MODELS
do
  mkdir $i
  cd $i
  cp ../$DATAFILE .

  for j in `seq ${TRAIN_NUM}`
  do
    run $i `pwd`
  done

  cd ..

done


# Deactivate the conda environment
conda deactivate
