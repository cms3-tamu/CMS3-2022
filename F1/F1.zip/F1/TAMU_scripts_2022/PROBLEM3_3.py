### Variational approach: linear case, load control test
### FFTMAD version 05/2019
### Linear simulation, testing strain and mixed control
### 3D

## STRESS AND MIXED CONTROL

from INPUT.RVE_generation import spheres_periodic
from SOLVERS.solverclass import simulation
from MAT_MODELS.materials import material
from POST.toParaview import toParaview
import matplotlib.pyplot as plt


folder='../results/'
nvoxels=2**5

#define simulation
my_simulation=simulation('Test_evp_composite','non-linear','variational-nw-cg-small')

#define options
my_simulation.set_options(threads=8,nlgeom='no',parallel_mat='umat-omp')
#
my_simulation.set_tolerances(toler_nw=1e-4,toler_lin=1e-5,maxiter_cg=1000)

#Model geometry

my_simulation.ndim=3
my_simulation.n=[nvoxels,nvoxels,nvoxels]
my_simulation.L=[1.,1.,1.]
my_simulation.prop=spheres_periodic(my_simulation.ndim,4,0.2,my_simulation.n,my_simulation.L)
  

# Material models and Properties

shear=1E9
Kvol=3E9
mm=0.1
depsilon0=1.
sigma_Y=10E6
h=100E6



my_materials=[]
my_materials.append(material('Matrix','umat',folder='umat_evp'))
my_materials[-1].set_properties(props=[mm,shear,depsilon0,Kvol,sigma_Y,h],sdv_num=15)
my_materials.append(material('Particle','umat',folder='umat_evp'))
my_materials[-1].set_properties(props=[mm,shear*10,depsilon0,Kvol*10,sigma_Y*10000,h],sdv_num=15)


#Define loads
# timer: [t_ini,t_end,min_dt,max_dt]
# control= 1 for stress 0 for strain
my_simulation.set_load_step(strain_ave_goal=[[0.2,0,0],[0,0,0],[0,0,0]],\
 timer=[.05,1,0.001,.1],stress_ave_goal=[[0,0,0],[0,0,0],[0,0,0]],\
 info=range(0),frec=1,incfix=0,control=[[0,1,1],[1,1,1],[1,1,1]])


## STUDENT: define loads


# Solving sequence
my_simulation.generate_green()
my_simulation.set_FP(my_materials)
my_simulation.solve(output=folder+my_simulation.jobname)

#post

toParaview(my_simulation)
print ('stress:', my_simulation.stress_ave)
print ('strain:', my_simulation.strain_ave)

plt.plot(my_simulation.strain_ave_inc[:,0,0],my_simulation.stress_ave_inc[:,0,0])

