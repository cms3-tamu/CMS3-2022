#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 22 05:57:58 2019

@author: javierseguradoescudero
"""
import numpy as np
# Green in 1D

N=2**5
E0 = 100E9
## 1D Greens function
Gamma0=np.ones(N)/E0
Gamma0[0]=0.
        
## Microstructure E(x)
E=  np.zeros(N)  
dE= np.zeros(N)  
for i in range(N):
    if i<N/2:
        E[i]=50E9
        dE[i]=E[i]-E0
    else:
        E[i]=150E9
        dE[i]=E[i]-E0
        
        
## Initial strain eps_app
eps_app=0.01

epsilon=np.array([eps_app]*N) # Initial value 
error,tol=1.,1E-6
while error>tol:
    tau = dE*epsilon
    tau_F= np.fft.fft(tau)
    epsilon_F = -Gamma0*tau_F
    epsilon_F[0]=eps_app*N
    epsilon_old=epsilon
    epsilon= np.fft.ifft(epsilon_F)
    error=np.linalg.norm(epsilon-epsilon_old)/eps_app
    print ('error',error)