### Script for elastic response in 3D
### FFTMAD version 05/2019
### Basic use of linear solvers: circle/sphere in square/cube
### 2D and 3D

from SOLVERS.solverclass import simulation
from MAT_MODELS.materials import material
from INPUT.RVE_generation import one_sphere
from POST.toParaview import toParaview

# Parametrization of the simulations, 2D and 3D and use of differente schemes
schemes = ['basic-strain','basic-accelerated','basic-augmented']
ndim=3
for scheme in schemes:
    print('CASE:'+str(ndim)+'D; '+scheme)
    my_simulation=simulation('Test1','linear',scheme)
    my_simulation.ndim=ndim
    
    # Generation of the microstructure        

 
    my_simulation.n=[2**5,2**5,2**5]
    my_simulation.L=[1.,1.,1.]
    my_simulation.prop=one_sphere(my_simulation.ndim,[0.5,0.5,0.5], \
 0.196,my_simulation.n,my_simulation.L)    
    
    # Material models and Properties
    my_materials=[]
    my_materials.append(material('aluminio','linear-elastic'))
    my_materials.append(material('SiC','linear-elastic'))
    my_materials[0].set_properties(E=70E7,nu=0.3)
    my_materials[1].set_properties(E=70E8,nu=0.3)
    
    #Loads
 
    my_simulation.set_load_step(strain_ave_goal=[[1E-1 ,0,0],[0,0,0],[0,0,0]])

    Eaver=(my_materials[0].E+my_materials[1].E)/2
    nuaver=(my_materials[0].nu+my_materials[1].nu)/2
    
    # Solving sequence
    my_simulation.generate_green(E0=Eaver,nu0=nuaver)
    my_simulation.set_FP(my_materials)
    my_simulation.solve(output='../results/'+my_simulation.jobname+'_CASE'+str(ndim)+'D_'+scheme)

    # Postprocessing
    toParaview(my_simulation)