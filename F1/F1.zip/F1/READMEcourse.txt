He logrado compilar pythono y dejar solo los .pyc. En esta situación es casi seguro que necesitemos python >3.5

Te mando un pdf actualizado con los ejercicios solo y el codigo.,

-Instala anaconda con python >3.5
-Instala pyevtk para usar paraview:
	-pyevtk (pip)
pip install pyevtk 

-Compila las subrutinas de material 
	-umat_evp
	-umat_cp_phen_iso
La linea es (linux) 

Para CP:
f2py -m umat --fcompiler=gnu95 --opt="-Ofast" -c umat.pyf umat.f # sin paralelizar 
f2py -m eval_fp_umat_finite --fcompiler=gnu95  --opt="-Ofast -fopenmp" --f77flags="-ffixed-line-length-132" -lgomp -c eval_fp_umat_finite.pyf eval_fp_umat_finite.f #paraleliizado 

Para evp:
f2py -m umat --fcompiler=gnu95 --opt="-Ofast" -c umat.pyf umat.f
f2py -m eval_fp_umat_small --fcompiler=gnu95  --opt="-Ofast -fopenmp" --f77flags="-ffixed-line-length-132" -lgomp -c eval_fp_umat_small.pyf eval_fp_umat_small.f

-(Opcional) Si queremos que acelear, instala pyfftw
	conda install -c conda-forge pyfftw


-(Opcional) si queremos acelerar los bucles de sumas, en OPERATORS hay que compilar esto

f2py -m einsumpyrr --fcompiler=gnu95  --opt="-Ofast -fopenmp"  -lgomp -c einsumpyrr.f

f2py -m einsumpyrc --fcompiler=gnu95  --opt="-Ofast -fopenmp"  -lgomp -c einsumpyrc.f

f2py -m einsumpycc --fcompiler=gnu95  --opt="-Ofast -fopenmp"  -lgomp -c einsumpycc.f

Dime si te va please, muchas gracizs por la ayuda y sobre todo ánimo con Nara, ya verás que pasa pronto el susto

Un abrazo
