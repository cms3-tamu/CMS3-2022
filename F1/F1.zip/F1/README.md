**Edit a file, create a new file, and clone from Bitbucket in under 2 minutes**

When you're done, you can delete the content in this README and update the file with details for others getting started with your repository.

*We recommend that you open this README in another tab as you perform the tasks below. You can [watch our video](https://youtu.be/0ocf7u76WSo) for a full demo of all the steps in this tutorial. Open the video in a new tab to avoid leaving Bitbucket.*

---

## Edit a file

You’ll start by editing this README file to learn how to edit a file in Bitbucket.

1. Click **Source** on the left side.
2. Click the README.md link from the list of files.
3. Click the **Edit** button.
4. Delete the following text: *Delete this line to make a change to the README from Bitbucket.*
5. After making your change, click **Commit** and then **Commit** again in the dialog. The commit page will open and you’ll see the change you just made.
6. Go back to the **Source** page.

---

## Create a file

Next, you’ll add a new file to this repository.

1. Click the **New file** button at the top of the **Source** page.
2. Give the file a filename of **contributors.txt**.
3. Enter your name in the empty file space.
4. Click **Commit** and then **Commit** again in the dialog.
5. Go back to the **Source** page.

Before you move on, go ahead and explore the repository. You've already seen the **Source** page, but check out the **Commits**, **Branches**, and **Settings** pages.

---

## Clone a repository

Use these steps to clone from SourceTree, our client for using the repository command-line free. Cloning allows you to work on your files locally. If you don't yet have SourceTree, [download and install first](https://www.sourcetreeapp.com/). If you prefer to clone from the command line, see [Clone a repository](https://confluence.atlassian.com/x/4whODQ).

1. You’ll see the clone button under the **Source** heading. Click that button.
2. Now click **Check out in SourceTree**. You may need to create a SourceTree account or log in.
3. When you see the **Clone New** dialog in SourceTree, update the destination path and name if you’d like to and then click **Clone**.
4. Open the directory you just created to see your repository’s files.

Now that you're more familiar with your Bitbucket repository, go ahead and add a new file locally. You can [push your change back to Bitbucket with SourceTree](https://confluence.atlassian.com/x/iqyBMg), or you can [add, commit,](https://confluence.atlassian.com/x/8QhODQ) and [push from the command line](https://confluence.atlassian.com/x/NQ0zDQ).



Fast Fourier Transform based homogenization code MADrid v.6.0

Authors: Javier Segurado, Sergio Lucarini
Colaborators: Jiun Lian, Miguel Spinola, Aitor Cruzado

Institute IMDEA Materials


An homogenization software for the boundary value problem.

Schemes:
'basic-strain': Moulinec and Suquet
'basic-stress': Moulinec and Suquet
'basic-accelerated': Moulinec and Suquet
'basic-augmented': Moulinec and Suquet
'variational-nw-cg-small': Zeeman and Geers
'variational-nw-cg-finite': Zeeman and Geers


Installation procedure:

1. sudo apt-get install gfortran
sudo apt-get install gcc-multilib
sudo apt-get install build-essential
sudo apt-get install libhdf5-dev
sudo apt-get install pkg-config
sudo apt-get install liblapack-dev
sudo apt-get install libblas-dev

2. Download Anaconda Distribution 2.7 from https://www.anaconda.com/download/
Execute sudo .bash Anaconda''.sh
location /pathto/anaconda2
yes (add to bashrc)

3. Install Nvidia Drivers correctly (automatic ubuntu)
Install Nvidi Toolkit only CUDA

4. Download f2py from https://sysbio.ioc.ee/projects/f2py2e/
pip install scipy --upgrade
tar -xf F2PY''.tar.gz
cd F2PY''
Replace in F2PY''/crackfortran.py:
as=b['args'] by asa=b['args']
else: as=args by else: asa=args
b=postcrack(b,as,tab=tab+'\t') by b=postcrack(b,asa,tab=tab+'\t')
sudo python setup.py install

5. Download FFTW package from http://www.fftw.org/download.html
tar -xf fftw''.tar.gz
cd fftw''
(in next three lines after CFLAGS="-fPIC" --prefix=pathtoFFTW can be added for local instalation)
./configure CFLAGS="-fPIC" --enable-threads --disable-shared --enable-static --enable-sse2 -enable-avx
make
sudo make install
make distclean
./configure CFLAGS="-fPIC" --enable-threads --disable-shared --enable-static --enable-sse2 --enable-avx --enable-float
make
sudo make install
make distclean
./configure CFLAGS="-fPIC" --enable-threads --disable-shared --enable-static --enable-long-double
make
sudo make install
make distclean
(if local installation -I/pathtoFFTW/include)
CFLAGS="-I/usr/local/include -Xlinker -Bsymbolic" pip install pyfftw

5. Add to .bashrc:
export CXXFLAGS="-D_GLIBCXX_USE_CXX11_ABI=0"
export CUDA_ROOT="/usr/local/cuda-8.0"
export PATH="$CUDA_ROOT/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_ROOT/lib64:$LD_LIBRARY_PATH"
cluster
export LPATH=$CUDA_ROOT:$LPATH
export LIBRARY_PATH="$CUDA_ROOT:$CUDA_ROOT/lib64:$CUDA_ROOT/lib:$LD_LIBRARY_PATH"
export LD_LIBRARY_PATH="$CUDA_ROOT:$CUDA_ROOT/lib64:$CUDA_ROOT/lib:$LD_LIBRARY_PATH"
export LDFLAGS=-L/$CUDA_ROOT/lib64:$LDFLAGS ???
copy libcuda.so to the path of installation???

sudo apt-get install libboost-all-dev
sudo apt-get install g++-multilib
Download pycuda from https://pypi.python.org/pypi/pycuda
tar -xf pycuda''
python configure.py --cxxflags="-D_GLIBCXX_USE_CXX11_ABI=0"
cluster:
python configure.py --cxxflags="-D_GLIBCXX_USE_CXX11_ABI=0" --python-exe="/home/sergio.lucarini/anaconda2/bin"
make
make install
sudo apt install ocl-icd-libopencl1
sudo apt install opencl-headers
sudo apt install clinfo
sudo apt install ocl-icd-opencl-dev
pip install pyopencl
pip install reikna

6. CORRECTIONS
In pycuda gpuarray.py (fix _new_like_me) (3 replaces)
#            result = self._new_like_me(dtype=real_dtype, order=order)
result = self._new_like_me(dtype=real_dtype)
In terminal (fix openmp in anaconda f2py)
check
strings /pathto/anaconda2/bin/../lib/libgomp.so.1 |grep GOMP
sudo find / -name libgomp.so.1*
ls -al /pathto/anaconda2/bin/../lib/libgomp.so.1
solve
sudo rm -rf /pathto/anaconda2/lib/libgomp.so.1
sudo ln -s /usr/lib/x86_64-linux-gnu/libgomp.so.1.0.0 /pathto/anaconda2/lib/libgomp.so.1
copy a newer version of libgomp.so.1.0.0 in /pathto/anaconda2/lib/libgomp.so.1.0.0 no!!!

7. VTK
pip install vtk
pip install pyevtk
pip install pyvoro



WINDOWS:

8. conda inastall mingw libpython


f2py --fcompiler=gnu95 --compiler=mingw32 -c umat.pyf umat.f

install anaconda python in c:\users\name\anacaonda (default)

en la carpeta Scripts dentro de anaconda creas f2py.bat con
python %~dp0/f2py.py %*

install mingw libraries in C:\MinGW

add path C:\MinGW\mingw64\bin
add C_INCLUDE_PATH as C:\MinGW\mingw64\include

to avoid comiple=---
creat c:\users\name\anacaonda\Lib\distutils\distutils.cfg
[build]
compiler=mingw32

conda install libpython
conda install cryptography

## only if not working conda install mingw #maybe then uninstall

f2py -m umat --fcompiler=gnu95 --opt="-Ofast" -c umat.pyf umat.f

f2py -m eval_fp_umat_finite --fcompiler=gnu95 --compiler=mingw32 --opt="-Ofast -fopenmp" --f77flags="-ffixed-line-length-132" -lgomp -c eval_fp_umat_finite.pyf eval_fp_umat_finite.f

f2py -m einsumpyrr --fcompiler=gnu95 --compiler=mingw32 --opt="-Ofast -fopenmp"  -lgomp -c einsumpyrr.f

f2py -m einsumpyrc --fcompiler=gnu95 --compiler=mingw32 --opt="-Ofast -fopenmp"  -lgomp -c einsumpyrc.f

f2py -m einsumpycc --fcompiler=gnu95 --compiler=mingw32 --opt="-Ofast -fopenmp"  -lgomp -c einsumpycc.f

pyfftw

https://www.lfd.uci.edu/~gohlke/pythonlibs/#pyfftw "Unofficial Windows Binaries for Python Extension Packages"

Download the FFTW for Windows from http://www.fftw.org/install/windows.html
Extract the zipped file and put the following files into Anaconda3\libs (not Anaconda3\lib):
libfftw3-3.dll, libfftw3f-3.dll, libfftw3l-3.dll,
libfftw3-3.def, libfftw3f-3.def, libfftw3l-3.def

Run "pip download pyfftw", extraxt *.tar the \pyFFTW-0.11.0\pyFFTW.egg-info\SOURCES.txt change/home/.../*.pyx por pyfftw/pyfftw.pyx y *.c por pyfftw/pyfftw.c
Run "pip install .\pyfftwversion"

move the following files to Anaconda3\Lib\site-packages\pyfftw
libfftw3-3.dll, libfftw3f-3.dll, libfftw3l-3.dll

Happy using Pyfftw!

Filter: Calculator
glob_disp0*iHat+glob_disp1*jHat+glob_disp2*kHat
disp0*iHat+disp1*jHat+disp2*kHat
