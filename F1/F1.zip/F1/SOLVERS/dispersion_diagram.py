from OPERATORS.general_functions import fftvec_c,ifftvec_c,fft_c,ifft_c,I4s,I2d4s
import numpy as np
from OPERATORS.FP import eval_FP,update_solution,restore_solution
import scipy.sparse.linalg as scisplin
import scipy.linalg
from POST.calculate_fields import calculate_fields_small
from POST.toParaview import toParaview,modestoParaview



def dispersion_diagram(simu):
    
    def M_operator(hat_u):

#        return fftvec_c(np.einsum('x,x->x',\
#        np.append(simu.rho_xyz,simu.rho_xyz),ifftvec_c(hat_u,simu)),simu)
        return fftvec_c(np.einsum('x,x->x',\
        np.array(simu.rho_xyz*simu.ndim),ifftvec_c(hat_u,simu)),simu)
        

    if(simu.ndim==2):
        C0=np.einsum('ijklx->ijkl',simu.C_glob)/(simu.n[0]*simu.n[1])
        kvectors=np.array(np.meshgrid(2.*np.fft.fftfreq(simu.n[0],simu.L[0])*np.pi*simu.n[0],\
                         2.*np.fft.fftfreq(simu.n[1],simu.L[1])*np.pi*simu.n[1]))\
                         .transpose(0,2,1).reshape(2,simu.n[0]*simu.n[1])
    else:
        C0=np.einsum('ijklx->ijkl',simu.C_glob)/(simu.n[0]*simu.n[1]*simu.n[2])
        kvectors=2.0*np.pi*np.einsum('i,ix->ix',simu.n,np.array(np.meshgrid(np.fft.fftfreq(simu.n[0],simu.L[0]),\
         np.fft.fftfreq(simu.n[1],simu.L[1]),\
         np.fft.fftfreq(simu.n[2],simu.L[2]) ))\
            .transpose(0,2,1,3).reshape(3,simu.n[0]*simu.n[1]*simu.n[2]))
       
    X=[]
    Xl=[]
    qtot=max(6,2*simu.numeigen)
    qreal = simu.numeigen
    
    for i in range(qtot):
        x=np.random.rand(simu.shape_vec)
        x=x/np.linalg.norm(x)
        X.append(x)
        Xl.append(x)
        
    X=np.array(X,dtype=complex)
    Xl = np.zeros([qtot,simu.shape_vec],dtype=complex)
    Xoldl=np.copy(Xl)
    KX=np.zeros([qtot,simu.shape_vec],dtype=complex)
    MX=np.zeros([qtot,simu.shape_vec],dtype=complex)
    Knew=np.zeros([qtot,qtot],dtype=complex)
    Mnew=np.zeros([qtot,qtot],dtype=complex)
    hatus=np.zeros([qtot,qtot],dtype=complex)
    simu.hatus_ord=np.zeros([qreal, simu.shape_vec])
    lambdas=np.ones([qreal])
    istep=0
    dispersion=[]
    
    for kv in simu.kvecs:
        
        istep+=1
        print('...starting step '+str(istep)+'; wave length '+str(kv)+'...')
     
        xik=create_xiplusk(kvectors,kv)  
        Ainvapp= Cxi_inv(C0,xik)

        iter=0
        error,error3=1,1

        lambdas=np.zeros([qtot])

        def A_operator(hat_u):
            uxk=ifft_c(np.einsum('kx,lx->klx',hat_u.reshape(simu.shape1),xik),simu) 
            forceF=np.einsum('ijx,jx->ix',fft_c(np.einsum('ijklx,klx->ijx',simu.C_glob,uxk),simu),xik)
            return forceF.reshape(simu.shape_vec)

        def Ainv_operator_N(hat_u,xold):
            status.count=0
            x,out=scisplin.cg(A=scisplin.LinearOperator(shape=[simu.shape_vec,simu.shape_vec],\
                matvec=A_operator),M=scisplin.LinearOperator(shape=[simu.shape_vec,simu.shape_vec],
                matvec=Ainv_operator_approx),x0=xold,\
                b=hat_u,callback=status,tol=simu.toler_lin)
            Ainv_operator_N.itertot  +=status.count
            Ainv_operator_N.inverses +=1
            print('Inverting linear operator using an iterative method',out,status.count,Ainv_operator_N.itertot)
            return x
        
            
        def Ainv_operator(hat_u):
            status.count=0
            x,out=scisplin.cg(A=scisplin.LinearOperator(shape=(simu.shape_vec,simu.shape_vec),\
                matvec=A_operator),M=scisplin.LinearOperator(shape=(simu.shape_vec,simu.shape_vec),
                matvec=Ainv_operator_approx),\
                b=hat_u,callback=status,tol=simu.toler_lin)
            Ainv_operator.inverses+=1
            Ainv_operator.itertot +=status.count
            print('Inverting linear operator using an iterative method',out,status.count, Ainv_operator.itertot)
            return x 

        def Ainv_operator_approx(hat_u):
            a= np.einsum('ijx,jx->ix',Ainvapp,hat_u.reshape(simu.shape1))
            return a.reshape(simu.shape_vec)  
        
        def status(x):
            status.count+=1
            return
        
        
        
        # Here Krylov method
             
        
        if(simu.eigenmethod=='arpack'):
            Ainv_operator.inverses=0
            Ainv_operator.itertot=0
            lambdas, X = scisplin.eigsh(A=scisplin.LinearOperator(shape=(simu.shape_vec,simu.shape_vec),\
            matvec=A_operator), sigma=0.,OPinv=scisplin.LinearOperator(shape=(simu.shape_vec,simu.shape_vec),\
            matvec=Ainv_operator),M=scisplin.LinearOperator(shape=(simu.shape_vec,simu.shape_vec),\
            matvec=M_operator),which='LM',tol=simu.toler_lin,k=simu.numeigen)
            X=X.T
    
     # Here subspace iteration method, Bathe
    
        elif(simu.eigenmethod=='subspace'):
       
            Ainv_operator_N.itertot=0
            Ainv_operator_N.inverses=0
            while error>simu.toler_lin  or error3>10*simu.toler_lin:
                
                iter+=1
                for i in range(qtot):
                    v=M_operator(X[i])    
                    
                    Xl[i]=Ainv_operator_N(v,Xoldl[i])
                    Xoldl[i]=np.copy(Xl[i])
                   
                    KX[i]=A_operator(Xl[i])
                    MX[i]=M_operator(Xl[i])
        
      
                Knew=np.dot(Xl.conjugate(),KX.T)
                Mnew=np.dot(Xl.conjugate(),MX.T)
    
                lambold=np.copy(lambdas)       
    
                lambdas,hatus=scipy.linalg.eigh(Knew,Mnew)
    
                X=np.dot(Xl.T,hatus).T 
               
                
                error=np.linalg.norm(lambold[0:qreal]-lambdas[0:qreal])\
                /np.linalg.norm(lambold[0:qreal])
        #        
                error3=0.
                for i in range(qreal):
                   vi=A_operator(X[i])
                   error3=max(error3,np.linalg.norm(vi-lambdas[i]*M_operator(X[i]))\
                          /np.linalg.norm(vi))
                error3=0.
    
                print ('iter subspace',iter,error,error3,lambdas[0:qreal])
                

#
        lambdas_ord = np.sort(lambdas)
        sequence=np.argsort(lambdas_ord)
        hatus_ord=X[sequence,:]
        
#        X=[]
#        for i in range(qtot):
#            x=np.random.rand(simu.shape_vec)
#            x=x/np.linalg.norm(x)
#            X.append(x)
        
        for i in range(qreal):      
            simu.hatus_ord[i]=ifftvec_c(hatus_ord[i],simu)
        
        modestoParaview(simu)             
        omega=(lambdas_ord)**.5
        dispersion.append(omega[0:qreal])
#        eigenvecs.append(simu.hatus_ord)
        print('omega t',omega[0])
        print('omega l',omega[1])

        
#    simu.eigenvecs=np.array(eigenvecs) 
    simu.dispersion=np.array(dispersion)
    simu.knorms = [np.linalg.norm(kv) for kv in simu.kvecs]
    
    
    
    
def Cxi_inv(C0,xik):
    n=np.shape(xik)[1]
    CC0= np.array([C0]*n,dtype='float',order='F').transpose(1,2,3,4,0)
    A=np.einsum('ijklx,jx,lx->ikx',CC0,xik,xik)
    Ainv_app=[ inv_condition(A[:,:,x])    for x in range(n)]
    return np.array(Ainv_app).transpose(1,2,0)

def inv_condition(A):
    try: 
        return np.linalg.inv(A)
    except:
        print('zero inv')
        return np.zeros(np.shape(A))
    
def create_xiplusk(kvectors,kv):

    l=len(kvectors[1])
    xitot=kvectors+np.array([kv]*l,dtype='float',order='F').transpose(1,0)

    return xitot  
    