from OPERATORS.general_functions import ddot42,fft,addOfreq,ifft,I4,I2,I4s
from POST.calculate_fields import calculate_fields_small
from POST.displacement import compute_displacement_small
import numpy as np
import scipy.sparse.linalg as scisplin
# Variational Conjugate Gradient
def kabel_small(simu):

    itertot=0
    Q=np.zeros([3,3,3,3],dtype='float',order='F')
    C0=simu.C0
    sbar=simu.stress_ave_goal[0]
    ebar=simu.strain_ave_goal[0]
    control=simu.control[0]
    for i in range(3):
        for j in range(3):
            Q[i][j][i][j]=control[i][j]
            if(control[i][j]==1):
                ebar[i][j]=0
            else:
                sbar[i][j]=0
    print 'ebar,sbar',ebar,sbar
    P=I4-Q    
    print 'P',P
    print 'Q',Q
    
    M=np.einsum('ijpq,pqrs,rskl->ijkl',Q,C0,Q)
    Minv=inv3333(M) 
    
    simu.strain_loc=np.zeros([3,3,simu.nvoxels],dtype='float',order='F')

# Note that this algorithm is M-S-fixed point!   
   
    for i in range(1):            
        simu.stress_loc=ddot42(simu.deltaC_glob,simu.strain_loc,simu) 
        print'stress ',simu.stress_loc[:,:,0]
        simu.stress_loc=fft(simu.stress_loc,simu)
        epsilon000=simu.stress_loc[:,:,0]
        simu.strain_loc=-1.*ddot42(simu.Gamma0_glob,simu.stress_loc,simu)
        simu.strain_loc[:,:,0]=(ebar+np.einsum('ijkl,kl->ij',Minv,(sbar-np.einsum('ijpq,pqkl,kl->ij',Q,C0,ebar)))\
                )*simu.nvoxels-np.einsum('ijpq,pqkl,kl->ij',Minv,Q,epsilon000)
        simu.strain_loc=ifft(simu.strain_loc,simu)

    simu.stress_loc=ddot42(simu.C_glob,simu.strain_loc,simu)
    sigma_ave=np.mean(simu.stress_loc,axis=2)
 
    
    Aux=np.einsum('ijkl,kl->ij',Minv,\
        (sbar-np.einsum('ijkl,kl->ij',Q,sigma_ave)))
    Aux_loc=np.add(Aux,np.zeros([simu.nvoxels,3,3],dtype='float',order='F')).transpose(1,2,0)
 
    bb=(-ifft(ddot42(simu.Gamma0_glob,fft(simu.stress_loc,simu),simu),simu)+Aux_loc).reshape(-1)
              
    def funct(var):
        Aux=ddot42(simu.deltaC_glob,var.reshape(simu.shape2),simu)
        Aux_mean=np.mean(Aux,axis=2)
        MQAux_mean=np.einsum('ijpq,pqkl,kl->ij',Minv,Q,Aux_mean)
        Aux_loc=np.add(MQAux_mean,np.zeros([simu.nvoxels,3,3],dtype='float',order='F')).transpose(1,2,0)
        return var+((ifft(ddot42(simu.Gamma0_glob,fft(Aux,simu),simu),simu))+\
          Aux_loc).reshape(-1)  
        
    def escr(x):
            escr.counter+=1
            return
    escr.counter=0
    tol=simu.toler_lin
   
    deltastrain_loc,X=scisplin.cg(tol=tol,\
                A=scisplin.LinearOperator(shape=(bb.size,bb.size),\
                matvec=funct,dtype='float'),\
                b=bb,callback=escr,maxiter=300)
    print 'iter cg ',escr.counter
    itertot+=escr.counter
    print 'iter total',itertot
    print 'maxdeltastrain_loc',max(deltastrain_loc)
    simu.strain_loc+=(deltastrain_loc).reshape(simu.shape2)
    simu.stress_loc=ddot42(simu.C_glob,simu.strain_loc,simu)
    simu.stress_ave=np.mean(simu.stress_loc,axis=2)
    simu.strain_ave=np.mean(simu.strain_loc,axis=2)
    print'stress_ave_goal',simu.stress_ave_goal 
    print'stress_ave',simu.stress_ave  
    print'strain_ave',simu.strain_ave
#    calculate_fields_basic(simu)
    return

def inv3333(M):
    import numpy as np
    MV=np.zeros([6,6])
    MV[0,0]=M[0,0,0,0]
    MV[0,1]=M[0,0,1,1]
    MV[0,2]=M[0,0,2,2]
    MV[0,3]=2*M[0,0,1,2]
    MV[0,4]=2*M[0,0,2,0]
    MV[0,5]=2*M[0,0,0,1]
    MV[1,0]=M[1,1,0,0]
    MV[1,1]=M[1,1,1,1]
    MV[1,2]=M[1,1,2,2]
    MV[1,3]=2*M[1,1,1,2]
    MV[1,4]=2*M[1,1,2,0]
    MV[1,5]=2*M[1,1,0,1]
    MV[2,0]=M[2,2,0,0]
    MV[2,1]=M[2,2,1,1]
    MV[2,2]=M[2,2,2,2]
    MV[2,3]=2*M[2,2,1,2]
    MV[2,4]=2*M[2,2,2,0]
    MV[2,5]=2*M[2,2,0,1]
    MV[3,0]=M[1,2,0,0]
    MV[3,1]=M[1,2,1,1]
    MV[3,2]=M[1,2,2,2]
    MV[3,3]=2*M[1,2,1,2]
    MV[3,4]=2*M[1,2,2,0]
    MV[3,5]=2*M[1,2,0,1]
    MV[4,0]=M[2,0,0,0]
    MV[4,1]=M[2,0,1,1]
    MV[4,2]=M[2,0,2,2]
    MV[4,3]=2*M[2,0,1,2]
    MV[4,4]=2*M[2,0,2,0]
    MV[4,5]=2*M[2,0,0,1]
    MV[5,0]=M[0,1,0,0]
    MV[5,1]=M[0,1,1,1]
    MV[5,2]=M[0,1,2,2]
    MV[5,3]=2*M[0,1,1,2]
    MV[5,4]=2*M[0,1,2,0]
    MV[5,5]=2*M[0,1,0,1]

    Minv=np.linalg.pinv(MV,1e-15)
    
    M=np.zeros([3,3,3,3])
    M[0,0,0,0]=Minv[0,0]
    M[0,0,1,1]=Minv[0,1]
    M[1,1,0,0]=Minv[1,0]
    M[1,1,1,1]=Minv[1,1]
    M[0,0,2,2]=Minv[0,2]
    M[2,2,0,0]=Minv[2,0]
    M[1,1,2,2]=Minv[1,2]
    M[2,2,1,1]=Minv[2,1]
    M[2,2,2,2]=Minv[2,2]
            
    M[0,0,0,1]=.5*Minv[0,5]
    M[0,0,1,0]=.5*Minv[0,5]
    M[0,0,0,2]=.5*Minv[0,4]
    M[0,0,2,0]=.5*Minv[0,4]
    M[0,0,1,2]=.5*Minv[0,3]
    M[0,0,2,1]=.5*Minv[0,3]
    
    M[1,1,0,1]=.5*Minv[1,5]
    M[1,1,1,0]=.5*Minv[1,5]
    M[1,1,0,2]=.5*Minv[1,4]
    M[1,1,2,0]=.5*Minv[1,4]
    M[1,1,1,2]=.5*Minv[1,3]
    M[1,1,2,1]=.5*Minv[1,3]

    M[2,2,0,1]=.5*Minv[2,5]
    M[2,2,1,0]=.5*Minv[2,5]
    M[2,2,0,2]=.5*Minv[2,4]
    M[2,2,2,0]=.5*Minv[2,4]
    M[2,2,1,2]=.5*Minv[2,3]
    M[2,2,2,1]=.5*Minv[2,3]
        
    M[1,2,0,0]=Minv[3,0]
    M[1,2,1,1]=Minv[3,1]
    M[1,2,2,2]=Minv[3,2]
    M[1,2,0,1]=.5*Minv[3,5]
    M[1,2,1,0]=.5*Minv[3,5]
    M[1,2,0,2]=.5*Minv[3,4]
    M[1,2,2,0]=.5*Minv[3,4]
    M[1,2,1,2]=.5*Minv[3,3]
    M[1,2,2,1]=.5*Minv[3,3]
        
    M[2,0,0,0]=Minv[4,0]
    M[2,0,1,1]=Minv[4,1]
    M[2,0,2,2]=Minv[4,2]
    M[2,0,0,1]=.5*Minv[4,5]
    M[2,0,1,0]=.5*Minv[4,5]
    M[2,0,0,2]=.5*Minv[4,4]
    M[2,0,2,0]=.5*Minv[4,4]
    M[2,0,1,2]=.5*Minv[4,3]
    M[2,0,2,1]=.5*Minv[4,3]
        
    M[0,1,0,0]=Minv[5,0]
    M[0,1,1,1]=Minv[5,1]
    M[0,1,2,2]=Minv[5,2]
    M[0,1,0,1]=.5*Minv[5,5]
    M[0,1,1,0]=.5*Minv[5,5]
    M[0,1,0,2]=.5*Minv[5,4]
    M[0,1,2,0]=.5*Minv[5,4]
    M[0,1,1,2]=.5*Minv[5,3]
    M[0,1,2,1]=.5*Minv[5,3]

    M[2,1,0,0]=Minv[3,0]
    M[2,1,1,1]=Minv[3,1]
    M[2,1,2,2]=Minv[3,2]
    M[2,1,0,1]=.5*Minv[3,5]
    M[2,1,1,0]=.5*Minv[3,5]
    M[2,1,0,2]=.5*Minv[3,4]
    M[2,1,2,0]=.5*Minv[3,4]
    M[2,1,1,2]=.5*Minv[3,3]
    M[2,1,2,1]=.5*Minv[3,3]
        
    M[0,2,0,0]=Minv[4,0]
    M[0,2,1,1]=Minv[4,1]
    M[0,2,2,2]=Minv[4,2]
    M[0,2,0,1]=.5*Minv[4,5]
    M[0,2,1,0]=.5*Minv[4,5]
    M[0,2,0,2]=.5*Minv[4,4]
    M[0,2,2,0]=.5*Minv[4,4]
    M[0,2,1,2]=.5*Minv[4,3]
    M[0,2,2,1]=.5*Minv[4,3]
        
    M[1,0,0,0]=Minv[5,0]
    M[1,0,1,1]=Minv[5,1]
    M[1,0,2,2]=Minv[5,2]
    M[1,0,0,1]=.5*Minv[5,5]
    M[1,0,1,0]=.5*Minv[5,5]
    M[1,0,0,2]=.5*Minv[5,4]
    M[1,0,2,0]=.5*Minv[5,4]
    M[1,0,1,2]=.5*Minv[5,3]
    M[1,0,2,1]=.5*Minv[5,3]
    return M
