from OPERATORS.general_functions import ddot42,ifft,fft,ifftvec,fftvec,I2d4,I4,odot11,dot21
from OPERATORS.general_functions import partition_indexes,dotdot141
import numpy as np
from OPERATORS.FP import eval_FP,update_solution,restore_solution
import scipy.sparse.linalg as scisplin
from POST.calculate_fields import calculate_fields_finite
from POST.toParaview import toParaview
# Displacement Based FFT newton-krylov for finite strains
def displacement_nw_cg_finite(simu):
    for simu.kstep in simu.rsteps:
        initialize_step(simu)
        while simu.time[0]<(simu.timer[simu.kstep-1][1]-1e-10):
            errorNW=1.
            simu.iter_nw=0
            simu.info=0
            simu.F_ave_inc_goal+=simu.deltaF_ave_inc_goal
            simu.PK1stress_ave_inc_goal+=simu.PK1stress_ave_inc_goal
            simu.u_loc_FFT=simu.u_loc_FFT+simu.Deltau_loc_FFT
            if simu.kinc==1:
                aux1=odot11(simu.u_loc_FFT,simu.qfreq,simu)
                aux1[:,:,0]=simu.F_ave_inc_goal*simu.nvoxels
                simu.F_loc=np.asfortranarray(ifft(np.asfortranarray(aux1),simu))
                eval_FP(simu)
                if np.any(simu.pnewdt!=1):
                    print('first umat failed',simu.dtime)
            if not np.any(simu.pnewdt!=1):
                du_loc_nw_CG(simu)
                if simu.info!=0:
                    print('first equilibriun not achieved',simu.dtime)
            if not np.any(simu.pnewdt!=1) and simu.info==0:
                simu.u_loc_FFT+=np.asfortranarray(simu.deltau_loc_FFT.reshape(simu.shape1fft))
                print('iterNW',simu.iter_nw,errorNW,'cg ',simu.it,'dt ',simu.dtime,simu.time[0])
            aux1=odot11(simu.u_loc_FFT,simu.qfreq,simu)
            aux1[:,:,0]=simu.F_ave_inc_goal*simu.nvoxels
            simu.F_loc=np.asfortranarray(ifft(np.asfortranarray(aux1),simu))
            while errorNW>simu.toler_nw and (not np.any(simu.pnewdt!=1)) and simu.info==0 and simu.iter_nw<simu.maxiter_nw:
                simu.iter_nw+=1
                eval_FP(simu)
                if np.any(simu.pnewdt!=1):
                    print('pnewdt reduction')
                    break
                du_loc_nw_CG(simu)
                if simu.info!=0:
                    print('equilibriun not achieved')
                    print('iterNW',simu.iter_nw,errorNW,'cg ',simu.it,'dt ',simu.dtime,simu.time[0])
                    break
                simu.u_loc_FFT+=np.asfortranarray(simu.deltau_loc_FFT.reshape(simu.shape1fft))
                aux1=odot11(simu.u_loc_FFT,simu.qfreq,simu)
                aux1[:,:,0]=simu.F_ave_inc_goal*simu.nvoxels
                F_loc_i=np.asfortranarray(ifft(np.asfortranarray(aux1),simu))
#                errorNW=np.max(np.abs(simu.deltau_loc_FFT))
                errorNW=np.max(np.abs(F_loc_i-simu.F_loc))/np.linalg.norm(np.average(F_loc_i,axis=2))
                simu.F_loc=F_loc_i
                print('iterNW',simu.iter_nw,errorNW,'cg ',simu.it,'dt ',simu.dtime,simu.time[0])
            if (not np.any(simu.pnewdt!=1)) and simu.info==0 and simu.iter_nw<simu.maxiter_nw:
                eval_FP(simu)
            if np.any(simu.pnewdt!=1) or simu.info!=0 or simu.iter_nw>=simu.maxiter_nw:
                restore_solution(simu)
                continue
            calculate_fields_finite(simu)
            simu.time[:]+=simu.dtime
            toParaview(simu)
            update_solution(simu)
            print('increment '+str(simu.kinc)+' completed')
            simu.kinc+=1
        print('step '+str(simu.kstep)+' completed')
    return


def du_loc_nw_CG(simu):
    def reduce2vec(field):
        reduce2vec.vect.fill(0)
        field=field.reshape(simu.shape1nfft)
        if simu.ndim==2:
            reduce2vec.vect[:,vi[0,0]:vi[0,1]]=field[:,fi[0,0,0]:fi[0,0,1],fi[0,1,0]:fi[0,1,1]].reshape(simu.ndim,si[0])
            reduce2vec.vect[:,vi[1,0]:vi[1,1]]=field[:,fi[1,0,0]:fi[1,0,1],fi[1,1,0]:fi[1,1,1]].reshape(simu.ndim,si[1])
            reduce2vec.vect[:,vi[2,0]:vi[2,1]]=field[:,fi[2,0,0]:fi[2,0,1],fi[2,1,0]:fi[2,1,1]].reshape(simu.ndim,si[2])
        elif simu.ndim==3:
            reduce2vec.vect[:,vi[0,0]:vi[0,1]]=field[:,fi[0,0,0]:fi[0,0,1],fi[0,1,0]:fi[0,1,1],fi[0,2,0]:fi[0,2,1]].reshape(simu.ndim,si[0])
            reduce2vec.vect[:,vi[1,0]:vi[1,1]]=field[:,fi[1,0,0]:fi[1,0,1],fi[1,1,0]:fi[1,1,1],fi[1,2,0]:fi[1,2,1]].reshape(simu.ndim,si[1])
            reduce2vec.vect[:,vi[2,0]:vi[2,1]]=field[:,fi[2,0,0]:fi[2,0,1],fi[2,1,0]:fi[2,1,1],fi[2,2,0]:fi[2,2,1]].reshape(simu.ndim,si[2])
            reduce2vec.vect[:,vi[3,0]:vi[3,1]]=field[:,fi[3,0,0]:fi[3,0,1],fi[3,1,0]:fi[3,1,1],fi[3,2,0]:fi[3,2,1]].reshape(simu.ndim,si[3])
            reduce2vec.vect[:,vi[4,0]:vi[4,1]]=field[:,fi[4,0,0]:fi[4,0,1],fi[4,1,0]:fi[4,1,1],fi[4,2,0]:fi[4,2,1]].reshape(simu.ndim,si[4])
            reduce2vec.vect[:,vi[5,0]:vi[5,1]]=field[:,fi[5,0,0]:fi[5,0,1],fi[5,1,0]:fi[5,1,1],fi[5,2,0]:fi[5,2,1]].reshape(simu.ndim,si[5])
            reduce2vec.vect[:,vi[6,0]:vi[6,1]]=field[:,fi[6,0,0]:fi[6,0,1],fi[6,1,0]:fi[6,1,1],fi[6,2,0]:fi[6,2,1]].reshape(simu.ndim,si[6])
            reduce2vec.vect[:,vi[7,0]:vi[7,1]]=field[:,fi[7,0,0]:fi[7,0,1],fi[7,1,0]:fi[7,1,1],fi[7,2,0]:fi[7,2,1]].reshape(simu.ndim,si[7])
        return reduce2vec.vect
    def expand2field(vect):
        expand2field.field.fill(0)
        vect=vect.reshape(simu.ndim,simu.nvoxelsfft2)
        if simu.ndim==2:
            expand2field.field[:,fi[0,0,0]:fi[0,0,1],fi[0,1,0]:fi[0,1,1]]=vect[:,vi[0,0]:vi[0,1]].reshape(simu.ndim,sf[0,0],sf[0,1])
            expand2field.field[:,fr[0,0,0]:fr[0,0,1]:fr[0,0,2],fr[0,1,0]:fr[0,1,1]:fr[0,1,2]]=np.conjugate(vect[:,vi[0,0]:vi[0,1]]).reshape(simu.ndim,sr[0,0],sr[0,1])
            expand2field.field[:,fi[1,0,0]:fi[1,0,1],fi[1,1,0]:fi[1,1,1]]=vect[:,vi[1,0]:vi[1,1]].reshape(simu.ndim,sf[1,0],sf[1,1])
            expand2field.field[:,fi[2,0,0]:fi[2,0,1],fi[2,1,0]:fi[2,1,1]]=vect[:,vi[2,0]:vi[2,1]].reshape(simu.ndim,sf[2,0],sf[2,1])
        elif simu.ndim==3:
            expand2field.field[:,fi[0,0,0]:fi[0,0,1],fi[0,1,0]:fi[0,1,1],fi[0,2,0]:fi[0,2,1]]=vect[:,vi[0,0]:vi[0,1]].reshape(simu.ndim,sf[0,0],sf[0,1],sf[0,2])
            expand2field.field[:,fi[1,0,0]:fi[1,0,1],fi[1,1,0]:fi[1,1,1],fi[1,2,0]:fi[1,2,1]]=vect[:,vi[1,0]:vi[1,1]].reshape(simu.ndim,sf[1,0],sf[1,1],sf[1,2])
            expand2field.field[:,fi[2,0,0]:fi[2,0,1],fi[2,1,0]:fi[2,1,1],fi[2,2,0]:fi[2,2,1]]=vect[:,vi[2,0]:vi[2,1]].reshape(simu.ndim,sf[2,0],sf[2,1],sf[2,2])
            expand2field.field[:,fi[3,0,0]:fi[3,0,1],fi[3,1,0]:fi[3,1,1],fi[3,2,0]:fi[3,2,1]]=vect[:,vi[3,0]:vi[3,1]].reshape(simu.ndim,sf[3,0],sf[3,1],sf[3,2])
            expand2field.field[:,fi[4,0,0]:fi[4,0,1],fi[4,1,0]:fi[4,1,1],fi[4,2,0]:fi[4,2,1]]=vect[:,vi[4,0]:vi[4,1]].reshape(simu.ndim,sf[4,0],sf[4,1],sf[4,2])
            expand2field.field[:,fi[5,0,0]:fi[5,0,1],fi[5,1,0]:fi[5,1,1],fi[5,2,0]:fi[5,2,1]]=vect[:,vi[5,0]:vi[5,1]].reshape(simu.ndim,sf[5,0],sf[5,1],sf[5,2])
            expand2field.field[:,fi[6,0,0]:fi[6,0,1],fi[6,1,0]:fi[6,1,1],fi[6,2,0]:fi[6,2,1]]=vect[:,vi[6,0]:vi[6,1]].reshape(simu.ndim,sf[6,0],sf[6,1],sf[6,2])
            expand2field.field[:,fi[7,0,0]:fi[7,0,1],fi[7,1,0]:fi[7,1,1],fi[7,2,0]:fi[7,2,1]]=vect[:,vi[7,0]:vi[7,1]].reshape(simu.ndim,sf[7,0],sf[7,1],sf[7,2])
            expand2field.field[:,fr[0,0,0]:fr[0,0,1]:fr[0,0,2],fr[0,1,0]:fr[0,1,1]:fr[0,1,2],fr[0,2,0]:fr[0,2,1]:fr[0,2,2]]=np.conjugate(vect[:,vi[0,0]:vi[0,1]]).reshape(simu.ndim,sr[0,0],sr[0,1],sr[0,2])
            expand2field.field[:,fr[1,0,0]:fr[1,0,1]:fr[1,0,2],fr[1,1,0]:fr[1,1,1]:fr[1,1,2],fr[1,2,0]:fr[1,2,1]:fr[1,2,2]]=np.conjugate(vect[:,vi[1,0]:vi[1,1]]).reshape(simu.ndim,sr[1,0],sr[1,1],sr[1,2])
            expand2field.field[:,fr[2,0,0]:fr[2,0,1]:fr[2,0,2],fr[2,1,0]:fr[2,1,1]:fr[2,1,2],fr[2,2,0]:fr[2,2,1]:fr[2,2,2]]=np.conjugate(vect[:,vi[2,0]:vi[2,1]]).reshape(simu.ndim,sr[2,0],sr[2,1],sr[2,2])
            expand2field.field[:,fr[3,0,0]:fr[3,0,1]:fr[3,0,2],fr[3,1,0]:fr[3,1,1]:fr[3,1,2],fr[3,2,0]:fr[3,2,1]:fr[3,2,2]]=np.conjugate(vect[:,vi[3,0]:vi[3,1]]).reshape(simu.ndim,sr[3,0],sr[3,1],sr[3,2])
        return expand2field.field
    def A_operator_disp(var):
        var0=var[:simu.ndim*simu.nvoxelsfft2]+1j*var[simu.ndim*simu.nvoxelsfft2:2*simu.ndim*simu.nvoxelsfft2]
        var1=expand2field(var0)
        var11=np.asfortranarray(odot11(var1.reshape(simu.shape1fft),simu.qfreq,simu))
        var11[Ic==1,0]=var[2*simu.ndim*simu.nvoxelsfft2:]*simu.nvoxels
        var2=ifft(var11.reshape(simu.shape2nfft),simu)
        var3=fft(ddot42(simu.tangent_glob,var2.reshape(simu.shape2),simu).reshape(simu.shape2n),simu)
        var4=dot21(var3.reshape(simu.shape2fft),simu.qfreq,simu)
        var5=reduce2vec(var4).reshape(-1)
        return np.append(np.append(np.real(var5),np.imag(var5)),np.real(var3[Ic==1,0])/simu.nvoxels)
    def pred(var):
        var0=var[:simu.ndim*simu.nvoxelsfft2]+1j*var[simu.ndim*simu.nvoxelsfft2:2*simu.ndim*simu.nvoxelsfft2]
        var1=expand2field(var0)
        var2=dot21(simu.pre,var1.reshape(simu.shape1fft),simu)
        varaux=np.zeros([simu.ndim,simu.ndim],dtype='float');varaux[Ic==1]=var[2*simu.ndim*simu.nvoxelsfft2:]
        varaux2=np.einsum('ij,ij->ij',np.real(simu.pre[:,:,0]),varaux)
        var3=reduce2vec(var2).reshape(-1)
        return np.append(np.append(np.real(var3),np.imag(var3)),varaux2[Ic==1])
    def escr(rr): escr.counter+=1; return
    precond(simu)
    fi,vi,si,sf,fr,sr=partition_indexes(simu.ndim,simu.n)
    expand2field.field=np.zeros(simu.shape1nfft,dtype='complex',order='F')
    reduce2vec.vect=np.zeros([simu.ndim,simu.nvoxelsfft2],dtype='complex',order='F')
    bb=-reduce2vec(dot21(np.asfortranarray(fft(simu.PK1stress_loc,simu)),simu.qq,simu)).reshape(-1)
    bb=np.append(np.append(np.real(bb),np.imag(bb)),simu.PK1stress_ave_inc_goal[Ic==1])
#    tol=simu.toler_lin; escr.counter=0
    tol=max(simu.toler_lin/np.linalg.norm(bb)*(simu.nvoxels), \
     simu.toler_lin); escr.counter=0
    xx,simu.info=scisplin.cg(tol=tol,\
        A=scisplin.LinearOperator(shape=(bb.size,bb.size),\
        matvec=A_operator_disp,dtype='float'),\
        M=scisplin.LinearOperator(shape=(bb.size,bb.size),\
        matvec=pred,dtype='float'),\
        b=bb,callback=escr,maxiter=simu.maxiter_cg)
#    xx=np.zeros([simu.ndim,simu.nvoxelsfft2],dtype='complex').reshape(-1)
#    xx=np.append(np.real(xx),np.imag(xx))
#    bcg=bb
#    rcg=np.copy(bcg)#-A_operator(xx)
#    zcg=pred(rcg)
#    pcg=np.copy(zcg)
#    rzoldcg=np.dot(np.transpose(rcg),zcg)
#    counter=0
#    errorcg=1e10
#    while errorcg>tol and counter<simu.maxiter_cg:
#        counter+=1
#        A_pcg=A_operator_disp(pcg)
#        alphacg=rzoldcg/(np.dot(np.transpose(pcg),A_pcg))
#        rcg=rcg-alphacg*A_pcg
#        xx=xx+alphacg*pcg
#        ###
#        alphacgpcg=alphacg*pcg
#        errorcg=np.max(np.abs(alphacgpcg))
#        ###
#        zcg=pred(rcg)
#        rznewcg=np.dot(np.transpose(rcg),zcg)
#        pcg=zcg+(rznewcg/rzoldcg)*pcg
#        rzoldcg=np.copy(rznewcg)
#    simu.it=counter
#    if counter>=simu.maxiter_cg:
#        simu.info=1
    simu.deltau_loc_FFT=expand2field(xx[:simu.ndim*simu.nvoxelsfft2]+\
     1.0j*xx[simu.ndim*simu.nvoxelsfft2:2*simu.ndim*simu.nvoxelsfft2]).reshape(simu.shape1fft)
    simu.it=escr.counter
    simu.F_ave_inc_goal[Ic==1]+=xx[2*simu.ndim*simu.nvoxelsfft2:]
    return

def initialize_step(simu):
    simu.dtime=np.array(simu.timer[simu.kstep-1][0],dtype='float',order='F')
    simu.deltaF_ave_inc_goal=(1.-simu.control[simu.kstep-1])*np.array((simu.F_ave_goal[simu.kstep-1]-\
     simu.F_ave)*simu.dtime/simu.timer[simu.kstep-1][1],dtype='float',order='F')
    simu.Deltau_loc_FFT=np.zeros(simu.shape1fft,dtype='complex',order='F')
    simu.deltaPK1stress_ave_inc_goal=(simu.control[simu.kstep-1])*np.array((simu.PK1stress_ave_goal[simu.kstep-1]\
     -simu.PK1stress_ave)*simu.dtime/simu.timer[simu.kstep-1][1],dtype='float',order='F')
#    simu.DeltaPK1stress_loc=np.array(((simu.control[simu.kstep-1])*np.array(\
#     [simu.deltaPK1stress_ave_inc_goal]*simu.nvoxels)).transpose(1,2,0),dtype='float',order='F')
    Ic=np.triu(simu.control[simu.kstep-1]+simu.control[simu.kstep-1].transpose(),1)\
     +np.eye(simu.ndim)*simu.control[simu.kstep-1];Ic[Ic==2]=1
    simu.kinc=np.array([1],dtype='int',order='F')
    simu.time[0]=0
    simu.pnewdt.fill(1.)
    if simu.ndim==3:
        Icontrol=np.einsum('ijkl,kl->ijkl',I4,simu.control[simu.kstep-1])
    if simu.ndim==2:
        Icontrol=np.einsum('ijkl,kl->ijkl',I2d4,simu.control[simu.kstep-1])    
    simu.qfreq=np.copy(simu.qq,order='F').reshape(simu.shape1nfft)
    if simu.ndim==2: 
        if simu.n[0]%2==0: simu.qfreq[:,simu.n[0]//2,:]=0
        if simu.n[1]%2==0: simu.qfreq[:,:,simu.n[1]//2]=0
    elif simu.ndim==3: 
        if simu.n[0]%2==0: simu.qfreq[:,simu.n[0]//2,:,:]=0
        if simu.n[1]%2==0: simu.qfreq[:,:,simu.n[1]//2,:]=0
        if simu.n[2]%2==0: simu.qfreq[:,:,:,simu.n[2]//2]=0
    simu.qfreq=simu.qfreq.reshape(simu.shape1fft)
    
def precond(simu):
#    if simu.n[0]%2==0: simu.qq[:,np.abs(np.imag(simu.kk_glob[0])+np.pi*simu.n[0]/simu.L[0])<1e-8]=1.
#    if simu.n[1]%2==0: simu.qq[:,np.abs(np.imag(simu.kk_glob[1])+np.pi*simu.n[1]/simu.L[1])<1e-8]=1.
#    if simu.ndim==3 and simu.n[2]%2==0: simu.qq[:,np.abs(np.imag(simu.kk_glob[2])+np.pi*simu.n[2]/simu.L[2])<1e-8]=1.
    simu.qq[:,0]=np.ones(simu.ndim)
#    idxs=np.where(simu.qq[:]==np.zeros([simu.ndim]))
#    print(idxs)
#    simu.qq[:,idxs]=np.ones([simu.ndim])
    if simu.C0 is None: simu.C0disp=np.average(simu.tangent_glob,axis=4)
    else: simu.C0disp=simu.C0
    simu.pre=np.linalg.inv(dotdot141(simu.C0disp,simu.qq,simu).transpose(2,0,1)).transpose(1,2,0)
#    simu.qq[:,idxs]=np.zeros([simu.ndim])
#    aux=np.einsum('ix,ijkl,lx->jkx',simu.qq,\
#     C0,simu.qq)
#    idxs=np.where(aux[:,:]==np.zeros([simu.ndim,simu.ndim]))[0]
#    aux=aux.transpose(2,0,1)
#    aux[idxs]=np.ones([simu.ndim,simu.ndim])
#    simu.pre=np.linalg.inv(aux).transpose(1,2,0)
#    if simu.ndim==2: 
#        if simu.n[0]%2==0: simu.pre[:,:,simu.n[0]//2,:]=0
#        if simu.n[1]%2==0: simu.pre[:,:,:,simu.n[1]//2]=0
#    elif simu.ndim==3: 
#        if simu.n[0]%2==0: simu.pre[:,:,simu.n[0]//2,:,:]=0
#        if simu.n[1]%2==0: simu.pre[:,:,:,simu.n[1]//2,:]=0
#        if simu.n[2]%2==0: simu.pre[:,:,:,:,simu.n[2]//2]=0
    simu.qq[:,0]=np.zeros(simu.ndim) 
#    if simu.n[0]%2==0: simu.qq[:,np.abs(np.imag(simu.kk_glob[0])+np.pi*simu.n[0]/simu.L[0])<1e-8]=0
#    if simu.n[1]%2==0: simu.qq[:,np.abs(np.imag(simu.kk_glob[1])+np.pi*simu.n[1]/simu.L[1])<1e-8]=0
#    if simu.ndim==3 and simu.n[2]%2==0: simu.qq[:,np.abs(np.imag(simu.kk_glob[2])+np.pi*simu.n[2]/simu.L[2])<1e-8]=0
#    if simu.n[0]%2==0: simu.pre[:,:,np.abs(np.imag(simu.kk_glob[0])+np.pi*simu.n[0]/simu.L[0])<1e-8]=0
#    if simu.n[1]%2==0: simu.pre[:,:,np.abs(np.imag(simu.kk_glob[1])+np.pi*simu.n[1]/simu.L[1])<1e-8]=0
#    if simu.ndim==3 and simu.n[2]%2==0: simu.pre[:,:,np.abs(np.imag(simu.kk_glob[2])+np.pi*simu.n[2]/simu.L[2])<1e-8]=0
