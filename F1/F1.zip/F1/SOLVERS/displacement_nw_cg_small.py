from OPERATORS.general_functions import ddot42,ifft,fft,ifftvec,fftvec,I2d4s,I4s
import numpy as np
from OPERATORS.FP import eval_FP,update_solution,restore_solution
import scipy.sparse.linalg as scisplin
from POST.calculate_fields import calculate_fields_small
from POST.toParaview import toParaview
# Displacement Based FFT newton-krylov for small strains
def displacement_nw_cg_small(simu):
    for simu.kstep in simu.rsteps:
        initialize_step(simu)
        while simu.time[0]<(simu.timer[simu.kstep-1][1]-1e-10):
            errorNW=1.
            simu.iter_nw=0
            simu.info=0
            simu.strain_ave_inc_goal+=simu.deltastrain_ave_inc_goal
            simu.stress_ave_inc_goal+=simu.stress_ave_inc_goal
            simu.u_loc_FFT=simu.u_loc_FFT+simu.Deltau_loc_FFT
            if simu.kinc==1:
                aux1=np.einsum('jx,ix->ijx',simu.qq,simu.u_loc_FFT)
                aux1[:,:,0]=simu.strain_ave_inc_goal*simu.nvoxels
                simu.strain_loc=ifft(np.asfortranarray(0.5*(aux1+aux1.transpose(1,0,2))),simu)
                eval_FP(simu)
                if np.any(simu.pnewdt!=1):
                    print('first umat failed',simu.dtime)
            if not np.any(simu.pnewdt!=1):
                du_loc_nw_CG(simu)
                if simu.info!=0:
                    print('first equilibriun not achieved',simu.dtime)
            if not np.any(simu.pnewdt!=1) and simu.info==0:
                simu.u_loc_FFT+=np.asfortranarray(simu.deltau_loc_FFT.reshape(simu.shape1fft))
                print('iterNW',simu.iter_nw,errorNW,'cg ',simu.it,'dt ',simu.dtime,simu.time[0])
            while errorNW>simu.toler_nw and (not np.any(simu.pnewdt!=1)) and simu.info==0 and simu.iter_nw<simu.maxiter_nw:
                simu.iter_nw+=1
                aux1=np.einsum('jx,ix->ijx',simu.qq,simu.u_loc_FFT)
                aux1[:,:,0]=simu.strain_ave_inc_goal*simu.nvoxels
                simu.strain_loc=ifft(np.asfortranarray(0.5*(aux1+aux1.transpose(1,0,2))),simu)
                eval_FP(simu)
                if np.any(simu.pnewdt!=1):
                    print('pnewdt reduction')
                    break
                du_loc_nw_CG(simu)
                if simu.info!=0:
                    print('equilibriun not achieved')
                    print('iterNW',simu.iter_nw,errorNW,'cg ',simu.it,'dt ',simu.dtime,simu.time[0])
                    break
                errorNW=np.max(np.abs(simu.deltau_loc_FFT))
                simu.u_loc_FFT+=np.asfortranarray(simu.deltau_loc_FFT.reshape(simu.shape1fft))
                print('iterNW',simu.iter_nw,errorNW,'cg ',simu.it,'dt ',simu.dtime,simu.time[0])
            if (not np.any(simu.pnewdt!=1)) and simu.info==0 and simu.iter_nw<simu.maxiter_nw:
                aux1=np.einsum('jx,ix->ijx',simu.qq,simu.u_loc_FFT)
                aux1[:,:,0]=simu.strain_ave_inc_goal*simu.nvoxels
                simu.strain_loc=ifft(np.asfortranarray(0.5*(aux1+aux1.transpose(1,0,2))),simu)
                eval_FP(simu)
            if np.any(simu.pnewdt!=1) or simu.info!=0 or simu.iter_nw>=simu.maxiter_nw:
                restore_solution(simu)
                continue
            calculate_fields_small(simu)
            simu.time[:]+=simu.dtime
            toParaview(simu)
            update_solution(simu)
            print('increment '+str(simu.kinc)+' completed')
            simu.kinc+=1
        print('step '+str(simu.kstep)+' completed')
    return


def du_loc_nw_CG(simu):
    def reduce2vec(field):
        reduce2vec.vect.fill(0)
        field=field.reshape(simu.shape1nfft)
        reduce2vec.vect[:,0:simu.nnew[0]//2]=field[:,1:simu.nnew[0]//2+1,0,0].reshape(simu.ndim,simu.nnew[0]//2)
        reduce2vec.vect[:,simu.nnew[0]//2:simu.nnew[0]*(simu.nnew[1]//2)+simu.nnew[0]//2]=field[:,0:simu.nnew[0],1:simu.nnew[1]//2+1,0].reshape(simu.ndim,simu.nnew[0]*(simu.nnew[1]//2))
        reduce2vec.vect[:,simu.nnew[0]*(simu.nnew[1]//2)+simu.nnew[0]//2:]=field[:,0:simu.nnew[0],0:simu.nnew[1],1:simu.nnew[2]].reshape(simu.ndim,simu.nnew[0]*simu.nnew[1]*(simu.nnew[2]//2))
        return reduce2vec.vect
    def expand2field(vect):
        expand2field.field.fill(0)
        vect=vect.reshape(simu.ndim,simu.nvoxelsfft2)
        expand2field.field[:,0,0,0]=np.zeros(simu.ndim,dtype='complex')
        expand2field.field[:,1:simu.nnew[0]//2+1,0,0]=vect[:,0:simu.nnew[0]//2].reshape(simu.ndim,simu.nnew[0]//2)
        expand2field.field[:,simu.nnew[0]-1:simu.nnew[0]//2:-1,0,0]=np.conjugate(vect[:,0:simu.nnew[0]//2]).reshape(simu.ndim,simu.nnew[0]//2)
        expand2field.field[:,0:simu.nnew[0],1:simu.nnew[1]//2+1,0]=vect[:,simu.nnew[0]//2:simu.nnew[0]*(simu.nnew[1]//2)+simu.nnew[0]//2].reshape(simu.ndim,simu.nnew[0],simu.nnew[1]//2)
        expand2field.field[:,0,simu.nnew[1]-1:simu.nnew[1]//2:-1,0]=np.conjugate(vect[:,simu.nnew[0]//2:simu.nnew[0]*(simu.nnew[1]//2)+simu.nnew[0]//2]).reshape(simu.ndim,simu.nnew[0],simu.nnew[1]//2)[:,0,0:simu.nnew[1]//2]
        expand2field.field[:,simu.nnew[0]-1:simu.nnew[0]//2:-1,simu.nnew[1]-1:simu.nnew[1]//2:-1,0]=\
         np.conjugate(vect[:,simu.nnew[0]//2:simu.nnew[0]*(simu.nnew[1]//2)+simu.nnew[0]//2]).reshape(simu.ndim,simu.nnew[0],simu.nnew[1]//2)[:,1:simu.nnew[0]//2+1,0:simu.nnew[1]//2]
        expand2field.field[:,simu.nnew[0]//2:0:-1,simu.nnew[1]-1:simu.nnew[1]//2:-1,0]=\
         np.conjugate(vect[:,simu.nnew[0]//2:simu.nnew[0]*(simu.nnew[1]//2)+simu.nnew[0]//2]).reshape(simu.ndim,simu.nnew[0],simu.nnew[1]//2)[:,simu.nnew[0]//2+1:,0:simu.nnew[1]//2]
        expand2field.field[:,0:simu.nnew[0],0:simu.nnew[1],1:simu.nnew[2]]=vect[:,simu.nnew[0]*(simu.nnew[1]//2)+simu.nnew[0]//2:].reshape(simu.ndim,simu.nnew[0],simu.nnew[1],simu.nnew[2]//2)
        return expand2field.field
    def A_operator_disp(var):
        var0=var[:simu.ndim*simu.nvoxelsfft2]+1j*var[simu.ndim*simu.nvoxelsfft2:2*simu.ndim*simu.nvoxelsfft2]
        var1=expand2field(var0)
        var12=np.einsum('jx,ix->ijx',simu.qq,var1.reshape(simu.shape1fft))
        var2=np.fft.irfftn(0.5*(var12+var12.transpose(1,0,2)).reshape(simu.shape2nfft),simu.n)
        var3=np.fft.rfftn(np.einsum('ijklx,klx->ijx',simu.tangent_glob,var2.reshape(simu.shape2)).reshape(simu.shape2n),simu.n)
        var4=np.einsum('jx,ijx->ix',simu.qq,var3.reshape(simu.shape2fft))
        var5=reduce2vec(var4).reshape(-1)
        return np.append(np.real(var5),np.imag(var5))
    def pred(var):
        var0=var[:simu.ndim*simu.nvoxelsfft2]+1j*var[simu.ndim*simu.nvoxelsfft2:2*simu.ndim*simu.nvoxelsfft2]
        var1=expand2field(var0)
        var2=np.einsum('ijx,jx->ix',simu.pre,var1.reshape(simu.shape1fft))
        var3=reduce2vec(var2).reshape(-1)
        return np.append(np.real(var3),np.imag(var3))
    def escr(rr): escr.counter+=1; return
    precond(simu)
    expand2field.field=np.zeros(simu.shape1nfft,dtype='complex')
    reduce2vec.vect=np.zeros([simu.ndim,simu.nvoxelsfft2],dtype='complex')
    bb=-reduce2vec(np.einsum('jx,ijx->ix',simu.qq,fft(simu.stress_loc,simu))).reshape(-1)
    bb=np.append(np.real(bb),np.imag(bb))
    tol=max(simu.toler_lin/np.linalg.norm(bb)*(simu.nvoxels), \
     simu.toler_lin); escr.counter=0
    xx,simu.info=scisplin.cg(tol=tol,\
        A=scisplin.LinearOperator(shape=(bb.size,bb.size),\
        matvec=A_operator_disp,dtype='float'),\
        M=scisplin.LinearOperator(shape=(bb.size,bb.size),\
        matvec=pred,dtype='float'),\
        b=bb,callback=escr,maxiter=simu.maxiter_cg)
    simu.deltau_loc_FFT=expand2field(xx[:simu.ndim*simu.nvoxelsfft2]+\
     1.0j*xx[simu.ndim*simu.nvoxelsfft2:2*simu.ndim*simu.nvoxelsfft2]).reshape(simu.shape1fft)
    simu.it=escr.counter
    return

def initialize_step(simu):
    simu.dtime=np.array(simu.timer[simu.kstep-1][0],dtype='float',order='F')
    simu.deltastrain_ave_inc_goal=(1-simu.control[simu.kstep-1])*np.array((simu.strain_ave_goal[simu.kstep-1]-\
     simu.strain_ave)*simu.dtime/simu.timer[simu.kstep-1][1],dtype='float',order='F')
    simu.Deltau_loc_FFT=np.zeros(simu.shape1fft,dtype='complex',order='F')
    simu.deltastress_ave_inc_goal=(simu.control[simu.kstep-1])*np.array((simu.stress_ave_goal[simu.kstep-1]\
     -simu.stress_ave)*simu.dtime/simu.timer[simu.kstep-1][1],dtype='float',order='F')
    simu.Deltastress_loc=np.array(((simu.control[simu.kstep-1])*np.array(\
     [simu.deltastress_ave_inc_goal]*simu.nvoxels)).transpose(1,2,0),dtype='float',order='F')
    simu.kinc=np.array([1],dtype='int',order='F')
    simu.time[0]=0
    simu.pnewdt.fill(1.)
    if simu.ndim==3:
        Icontrol=np.einsum('ijkl,kl->ijkl',I4s,simu.control[simu.kstep-1])
    if simu.ndim==2:
        Icontrol=np.einsum('ijkl,kl->ijkl',I2d4s,simu.control[simu.kstep-1])    
    
def precond(simu):
#    if simu.n[0]%2==0: simu.qq[:,np.abs(np.imag(simu.kk_glob[0])+np.pi*simu.n[0]/simu.L[0])<1e-8]=1.
#    if simu.n[1]%2==0: simu.qq[:,np.abs(np.imag(simu.kk_glob[1])+np.pi*simu.n[1]/simu.L[1])<1e-8]=1.
#    if simu.ndim==3 and simu.n[2]%2==0: simu.qq[:,np.abs(np.imag(simu.kk_glob[2])+np.pi*simu.n[2]/simu.L[2])<1e-8]=1.
    simu.qq[:,0]=np.ones(simu.ndim)
    if simu.C0 is None: C0=np.average(simu.tangent_glob,axis=4)
    else: C0=simu.C0
    simu.pre=np.linalg.inv(np.einsum('ix,ijkl,lx->jkx',simu.qq,\
     C0,simu.qq).transpose(2,0,1)).transpose(1,2,0)
    simu.qq[:,0]=np.zeros(simu.ndim) 
#    if simu.n[0]%2==0: simu.qq[:,np.abs(np.imag(simu.kk_glob[0])+np.pi*simu.n[0]/simu.L[0])<1e-8]=0
#    if simu.n[1]%2==0: simu.qq[:,np.abs(np.imag(simu.kk_glob[1])+np.pi*simu.n[1]/simu.L[1])<1e-8]=0
#    if simu.ndim==3 and simu.n[2]%2==0: simu.qq[:,np.abs(np.imag(simu.kk_glob[2])+np.pi*simu.n[2]/simu.L[2])<1e-8]=0
#    if simu.n[0]%2==0: simu.pre[:,:,np.abs(np.imag(simu.kk_glob[0])+np.pi*simu.n[0]/simu.L[0])<1e-8]=0
#    if simu.n[1]%2==0: simu.pre[:,:,np.abs(np.imag(simu.kk_glob[1])+np.pi*simu.n[1]/simu.L[1])<1e-8]=0
#    if simu.ndim==3 and simu.n[2]%2==0: simu.pre[:,:,np.abs(np.imag(simu.kk_glob[2])+np.pi*simu.n[2]/simu.L[2])<1e-8]=0
