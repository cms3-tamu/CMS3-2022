import numpy as np
import shutil
import os
from multiprocessing import Process
import matplotlib.pyplot as plt
from vtk import vtkStructuredPointsReader
from vtk import vtkXMLStructuredGridReader
from vtk import vtkXMLRectilinearGridReader
from vtk.util import numpy_support as VN

### FIP extractor for grain averaging and band averaging in cubed polycrystals ###
def extract(n,bandn,l,euler_input_name,phase_input_name,fip_input_name,fipsdv,eulersdv):
    def get_positions(n,l):
        pos=np.zeros([3,n[0],n[1],n[2]])
        aux=np.zeros([n[1],n[2],n[0]])
        aux2=np.zeros([n[2],n[0],n[1]])
        pos[2,:]=np.arange(n[2])*l[2]/n[2]+0.5*l[2]/n[2]
        aux[:]=(np.arange(n[0])*l[0]/n[0]+0.5*l[0]/n[0])
        pos[0,:]=aux[:].transpose(2,0,1)
        aux2[:]=np.arange(n[1])*l[1]/n[1]+0.5*l[1]/n[1]
        pos[1,:]=aux2[:].transpose(1,2,0)
        return pos.reshape([3,n[0]*n[1]*n[2]]).transpose(1,0)
    
    def get_phases(filename,n):
        if filename[-3:]=='vtk':
            sdv=np.zeros([(n[0]+1)*(n[1]+1)*(n[2]+1)])
            fvtk=open(filename,'r')
            read=0
            countern=0
            for line in fvtk:
                if line[0:9]=='Materials':
                    read=1
                    continue
                if read==1:
                    if len(line)<30:
                        read=0
                        continue
                    for num in line.split():
                        sdv[countern]=float(num)
                        countern+=1
            fvtk.close()
        if filename[-3:]=='vts':
            reader=vtkXMLStructuredGridReader()
            reader.SetFileName(filename)
            reader.Update()
            data = reader.GetOutput()  
            sdv=VN.vtk_to_numpy(data.GetPointData().GetArray('matpoint'))
        if filename[-3:]=='vtr':
            reader=vtkXMLRectilinearGridReader()
            reader.SetFileName(filename)
            reader.Update()
            data = reader.GetOutput()
            sdv=VN.vtk_to_numpy(data.GetPointData().GetArray('matpoint'))
#        sdv2=sdv.reshape([n[2]+1,n[1]+1,n[0]+1]).transpose(2,1,0)[0:n[0],0:n[1],0:n[2]].flatten()
        sdv2=sdv.flatten()
        return sdv2
    
    def read_sdv(filename,n,order):
        if filename[-3:]=='vtk':
            sdv=np.zeros([(n[0]+1)*(n[1]+1)*(n[2]+1)])
            fvtk=open(filename,'r')
            read=0
            countern=0
            for line in fvtk:
                if line[0:7]=='SDV_'+str(order):
                    read=1
#                    print 'readvtk'+line[0:7]
                    continue
                if read==1:
                    if len(line)<25:
                        read=0
                        continue
                    for num in line.split():
                        sdv[countern]=float(num)
                        countern+=1
            fvtk.close()
        if filename[-3:]=='vts':
#            print filename,'sdv'+str(order)
            reader=vtkXMLStructuredGridReader()
            reader.SetFileName(filename)
            reader.Update()
            data = reader.GetOutput()  
            sdv=VN.vtk_to_numpy(data.GetCellData().GetArray('sdv'+str(order)))
#            sdv=VN.vtk_to_numpy(data.GetPointData().GetArray('sdv'+str(order)))
#        sdv2=sdv.reshape([n[2]+1,n[1]+1,n[0]+1]).transpose(2,1,0)[0:n[0],0:n[1],0:n[2]].flatten()
#        sdv2=sdv.reshape([n[2],n[1],n[0]]).transpose(2,1,0).flatten()
        if filename[-3:]=='vtr':
#            print filename,'sdv'+str(order)
            reader=vtkXMLRectilinearGridReader()
            reader.SetFileName(filename)
            reader.Update()
            data = reader.GetOutput()
            sdv=VN.vtk_to_numpy(data.GetPointData().GetArray('sdv'+str(order)))
        sdv2=sdv.flatten()
#        sdv2=sdv
#            print 'totel'+str(countern)
        return sdv2
    
    positions=get_positions(n,l)
    phases=get_phases(phase_input_name,n)
    euler=np.ndarray([3,n[0]*n[1]*n[2]])
    
    
    for i in range(len(eulersdv)):
        euler[i]=read_sdv(euler_input_name,n,eulersdv[i])
    fip=np.ndarray([len(fipsdv),n[0]*n[1]*n[2]])
    for i in range(len(fipsdv)):
        fip[i]=read_sdv(fip_input_name,n,fipsdv[i])
    
    #def listaaver(phase,euler,pos,n,l,bandn):
    phase=np.array(phases,dtype='int')-1
    pos=positions
    if True:
        ddplano=bandn*l.mean()/n.mean()
        rr44=np.arange(4)
#        print np.max(phase)
        crystalsnum=int(np.max(phase)+1)
        eulercrys=np.zeros([crystalsnum,3],dtype='float',order='F')
        indexelempercrys=[]
        for i in np.arange(crystalsnum):
            indexelempercrys.append([])
        for i in np.arange(phase.size):
            indexelempercrys[phase[i]].append(i)
        for i in np.arange(crystalsnum):
            indexelempercrys[i]=np.array(indexelempercrys[i])
        for i in np.arange(crystalsnum):
            eulercrys[i,:]=euler[:,indexelempercrys[i]].mean(axis=1)
        crystalplane=np.array([[1,1,1],[1,-1,1],[-1,-1,1],[-1,1,1]],dtype='float',order='F')
        listavectoresnormales=np.zeros([crystalsnum,4,3],dtype='float',order='F')
        for i in np.arange(crystalsnum):
            rotationmatrix=np.array([[np.cos(eulercrys[i,2]*np.pi/180)*np.cos(eulercrys[i,0]*np.pi/180)-\
             np.sin(eulercrys[i,0]*np.pi/180)*np.sin(eulercrys[i,2]*np.pi/180)*np.cos(eulercrys[i,1]*np.pi/180),\
             np.cos(eulercrys[i,2]*np.pi/180)*np.sin(eulercrys[i,0]*np.pi/180)+\
             np.cos(eulercrys[i,0]*np.pi/180)*np.sin(eulercrys[i,2]*np.pi/180)*np.cos(eulercrys[i,1]*np.pi/180),\
             np.sin(eulercrys[i,1]*np.pi/180)*np.sin(eulercrys[i,2]*np.pi/180)],\
             [-np.sin(eulercrys[i,2]*np.pi/180)*np.cos(eulercrys[i,0]*np.pi/180)-\
             np.sin(eulercrys[i,0]*np.pi/180)*np.cos(eulercrys[i,2]*np.pi/180)*np.cos(eulercrys[i,1]*np.pi/180),\
             -np.sin(eulercrys[i,0]*np.pi/180)*np.sin(eulercrys[i,2]*np.pi/180)+\
             np.cos(eulercrys[i,0]*np.pi/180)*np.cos(eulercrys[i,2]*np.pi/180)*np.cos(eulercrys[i,1]*np.pi/180),\
             np.cos(eulercrys[i,2]*np.pi/180)*np.sin(eulercrys[i,1]*np.pi/180)],\
             [np.sin(eulercrys[i,0]*np.pi/180)*np.sin(eulercrys[i,1]*np.pi/180),\
             -np.sin(eulercrys[i,1]*np.pi/180)*np.cos(eulercrys[i,0]*np.pi/180),\
             np.cos(eulercrys[i,1]*np.pi/180)]],dtype='float',order='F')
            for j in rr44:
                listavectoresnormales[i,j]=np.einsum('ij,j->i',\
                 rotationmatrix,crystalplane[j])
                listavectoresnormales[i,j]=listavectoresnormales[i,j]/\
                 np.linalg.norm(listavectoresnormales[i,j])*ddplano/2
        indexelemperband=[]
        for i in np.arange(crystalsnum):
#            print 'crystal '+str(i+1)+' bandsize'+str(len(indexelempercrys[i]))
#            allindex=np.where(phase==i+1)[0]
            poscrys=pos[indexelempercrys[i],:]
            if poscrys[:,0].size==1:
#                print poscrys[:,0],np.sort(poscrys[:,0]),np.ediff1d(np.sort(poscrys[:,0]))
                indexelemperband.append(indexelempercrys[i])
                continue
            if np.max(np.ediff1d(np.sort(poscrys[:,0])))>l[0]*1.00001/n[0]:
                poscrys[np.argsort(poscrys[:,0])[0:np.argmax(np.ediff1d(np.sort(poscrys[:,0])))+1],0]=\
                 poscrys[np.argsort(poscrys[:,0])[0:np.argmax(np.ediff1d(np.sort(poscrys[:,0])))+1],0]+l[0]
            if np.max(np.ediff1d(np.sort(poscrys[:,1])))>l[1]*1.00001/n[1]:
                poscrys[np.argsort(poscrys[:,1])[0:np.argmax(np.ediff1d(np.sort(poscrys[:,1])))+1],1]=\
                 poscrys[np.argsort(poscrys[:,1])[0:np.argmax(np.ediff1d(np.sort(poscrys[:,1])))+1],1]+l[1]
            if np.max(np.ediff1d(np.sort(poscrys[:,2])))>l[2]*1.00001/n[2]:
                poscrys[np.argsort(poscrys[:,2])[0:np.argmax(np.ediff1d(np.sort(poscrys[:,2])))+1],2]=\
                 poscrys[np.argsort(poscrys[:,2])[0:np.argmax(np.ediff1d(np.sort(poscrys[:,2])))+1],2]+l[2]
            for el in np.arange(indexelempercrys[i].size):
                for j in rr44:
                    lower=listavectoresnormales[i,j,0]*(poscrys[el,0]-listavectoresnormales[i,j,0])+\
                     listavectoresnormales[i,j,1]*(poscrys[el,1]-listavectoresnormales[i,j,1])+\
                     listavectoresnormales[i,j,2]*(poscrys[el,2]-listavectoresnormales[i,j,2])
                    upper=listavectoresnormales[i,j,0]*(poscrys[el,0]+listavectoresnormales[i,j,0])+\
                     listavectoresnormales[i,j,1]*(poscrys[el,1]+listavectoresnormales[i,j,1])+\
                     listavectoresnormales[i,j,2]*(poscrys[el,2]+listavectoresnormales[i,j,2])
                    center=listavectoresnormales[i,j,0]*(poscrys[el,0])+\
                     listavectoresnormales[i,j,1]*(poscrys[el,1])+\
                     listavectoresnormales[i,j,2]*(poscrys[el,2])
                    rest=listavectoresnormales[i,j,0]*(poscrys[:,0])+\
                     listavectoresnormales[i,j,1]*(poscrys[:,1])+\
                     listavectoresnormales[i,j,2]*(poscrys[:,2]) 
                    if lower<center<upper:
                        indexelemperband.append(indexelempercrys[i][np.where(np.logical_and(lower<rest,rest<upper))[0]])
                    if lower>center>upper:
                        indexelemperband.append(indexelempercrys[i][np.where(np.logical_and(lower>rest,rest>upper))[0]])
    
    allgrains=len(indexelempercrys)
    grainaver=np.zeros(allgrains)
    for i in np.arange(allgrains):
        grainaver[i]=fip[0,indexelempercrys[i]].mean()
    allbands=len(indexelemperband)
    bandaver=np.zeros(3*allbands)
    lenband=np.zeros(3*allbands,dtype='int')
    for i in np.arange(allbands):
        bandaver[i]=fip[i%4*3+1,indexelemperband[i]].mean()
        bandaver[i+allbands]=fip[i%4*3+2,indexelemperband[i]].mean()
        bandaver[i+2*allbands]=fip[i%4*3+3,indexelemperband[i]].mean()
        lenband[i]=indexelemperband[i].size
        lenband[i+allbands]=indexelemperband[i].size
        lenband[i+2*allbands]=indexelemperband[i].size
    return grainaver,bandaver,lenband

def FIPextraction(n,bandn,l,outputname):
    n=n # discretization of the cubed polycrystal
    bandn=bandn # number of elemens of band thickness
    l=l# lenth of the cubed polycrystal
    euler_input=outputname+'0001.vtr' # .rpt (increment 1 of step 1) or .vtk or .inp
    phase_input=outputname+'0001.vtr' # .dx or .vtk or .inp
    fip_input=outputname+'0002.vtr' # .rpt (increment 1 of step 7) or .vtk
#    print(euler_input)
    fipsdv=[175,204,205,206,207,208,209,210,211,212,213,214,215] #sdvlist for fip
    eulersdv=[216,217,218] #sdvlist for euler angles
    euler_input_name=euler_input
    phase_input_name=phase_input
    fip_input_name=fip_input
    grainaver,bandaver,lenband=extract(n,bandn,l,euler_input_name,phase_input_name,fip_input_name,fipsdv,eulersdv)
    fopen=open(outputname+'extractfip.txt','w')
    fopen.write('# grain band\n')
    fopen.write('%e %e' % (np.max(grainaver),np.max(bandaver)))
    fopen.close()
    np.savetxt(outputname+'allfip.txt',bandaver)
    np.savetxt(outputname+'lenfip.txt',lenband)








