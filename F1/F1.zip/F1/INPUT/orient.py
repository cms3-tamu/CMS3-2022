##### INPUT functions for orientation
import numpy as np

def rand_ori_umat():
    """
    Generate random orientations for a umat, outputs an array of the
    3D rotation matrix: [Rxx, Ryx, Rzx, Rxy, Ryy, Rzy, Rxz, Ryz, Rzz]
    """
    u1=np.random.rand()
    u2=np.random.rand()
    u3=np.random.rand()   
    ph=u1*360.
    th=(180./np.pi)*np.arccos(1.-2.*u2)
    tm=360.*u3
    sph=np.sin(ph*np.pi/180.)
    cph=np.cos(ph*np.pi/180.)
    sth=np.sin(th*np.pi/180.)
    cth=np.cos(th*np.pi/180.)
    stm=np.sin(tm*np.pi/180.)
    ctm=np.cos(tm*np.pi/180.)
    props=np.ndarray(9,dtype='float64',order='F')
    props[0]=ctm*cph-sph*stm*cth
    props[1]=ctm*sph+cph*stm*cth   
    props[2]=sth*stm    
    props[3]=-stm*cph-sph*ctm*cth
    props[4]=-sph*stm+cph*ctm*cth 
    props[5]=ctm*sth    
    props[6]=sph*sth
    props[7]=-sth*cph    
    props[8]=cth
    return props

def read_ori_aba(filename):
    """
    Reads 6 properties defined on each user matrerial of an abaqus
    input file, ouputs a list of x raws of materials
    and 6 columns properties
    """
    f = open(filename, 'r')
    conv=[]
    take=0
    for line in f:
        if take==1:
           conv.append([])
           aa=line.split()
           for i in aa:
               conv[-1].append(float(i[0:-1]))
           take=0
        if line[0:15]==' *USER MATERIAL':
            take=1
    f.close()
    return np.array(conv)

def euler_to_R(theta):
    ph,th,tm=theta[0],theta[1],theta[2]
    sph=np.sin(ph*np.pi/180.)
    cph=np.cos(ph*np.pi/180.)
    sth=np.sin(th*np.pi/180.)
    cth=np.cos(th*np.pi/180.)
    stm=np.sin(tm*np.pi/180.)
    ctm=np.cos(tm*np.pi/180.)
    props=np.zeros(9)
    props[0]=ctm*cph-sph*stm*cth
    props[3]=ctm*sph+cph*stm*cth   
    props[6]=sth*stm    
    props[1]=-stm*cph-sph*ctm*cth
    props[4]=-sph*stm+cph*ctm*cth 
    props[7]=ctm*sth    
    props[2]=sph*sth
    props[5]=-sth*cph    
    props[8]=cth
    return props

def R_to_euler(a):
    a=a.transpose()
    th=np.arccos(a[2,2])
    if abs(a[2,2])>=0.9999:
        tm=0.
        th=np.atan2(a[0,1],a[0,0])
    else:
        sth=np.sin(th)
        tm=np.arctan2(a[0,2]/sth,a[1,2]/sth)
        ph=np.arctan2(a[2,0]/sth,-a[2,1]/sth)
    th=th*180./np.pi
    ph=ph*180./np.pi
    tm=tm*180./np.pi
    return ph,th,tm

