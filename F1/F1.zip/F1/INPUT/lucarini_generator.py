# -*- coding: utf-8 -*-
"""
Created on Thu May 03 12:21:38 2018

@author: sergio.lucarini
generate a polycrystal
"""
import numpy as np
import scipy.stats as st



def gen_per_poly(name,ndim,n,L,mu,sigma,rmin,rmax):
    """
    Parameters
    ----------
    name : str
        name of the output
    ndim : int
        number of dimensions
    n : int array (ndim)
        discretization nx ny (nz)
    L : float array (ndim)
        length Lx Ly (Lz)
    mu : float
        mean diameter
    sigma : float
        deviation for the lognorm = np.log(standar  deviation
        (in length untis))
    rmin : float
        minimum readius in lenght units
    rmax : float
        maximum readius in lenght units

    Returns
    -------
    prop : int array of nx,ny(,nz) dimensions 
        phase numbers of the multiplicative weighted voronoi tesellation

    """
    ntot=n[0]*n[1]*n[2]
    vol_tot=L[0]*L[1]*L[2]
    h=np.array([[-L[0],-L[1],-L[2]],[-L[0],-L[1],0],[-L[0],-L[1],L[2]],\
        [-L[0],0,-L[2]],[-L[0],0,0],[-L[0],0,L[2]],\
        [-L[0],L[1],-L[2]],[-L[0],L[1],0],[-L[0],L[1],L[2]],\
        [0,-L[1],-L[2]],[0,-L[1],0],[0,-L[1],L[2]],\
        [0,0,-L[2]],[0,0,0],[0,0,L[2]],\
        [0,L[1],-L[2]],[0,L[1],0],[0,L[1],L[2]],\
        [L[0],-L[1],-L[2]],[L[0],-L[1],0],[L[0],-L[1],L[2]],\
        [L[0],0,-L[2]],[L[0],0,0],[L[0],0,L[2]],\
        [L[0],L[1],-L[2]],[L[0],L[1],0],[L[0],L[1],L[2]]])
    images=np.int(3**ndim)


    
    def volume(r,ndim):
        return 4./3.*r**3*np.pi
    

    
    mean=np.exp(np.log(mu)+sigma**2./2.)
    mean_vol=volume(mean/2.,ndim)
    tol=mean_vol/2.
    crys_esti=vol_tot/mean_vol
    crys_max=np.int(np.round(2*crys_esti))
    rr=np.zeros(crys_max)
    vol=0;car=0
    while vol<vol_tot-tol:
        rr[car]=st.lognorm.rvs(sigma,0,mu)/2.
        vol+=volume(rr[car],ndim)
        car+=1
    rr=np.repeat(rr[0:car],images)
    
    collocation=np.zeros([car*images])
    packings=np.zeros([car*images])
    xc=np.zeros([car*images,ndim])
    
    for i in range(0,car):
        packing=1.
        itercol=0
        ies=np.where(collocation==2)[0]
        rres=rr[ies]
        xces=xc[ies]
        while np.all(collocation[images*i:images*(i+1)]==0):
            x=np.random.rand(ndim)*L
    
            diff=x-xces
    
            distances=np.sqrt(np.einsum('xi,xi->x',diff,diff))
    
            if not np.any(distances<rr[i*images+images//2]/packing+rres):
                collocation[images*i:images*(i+1)]=2
                packings[images*i:images*(i+1)]=packing
                xc[images*i:images*(i+1)]=(x+h).reshape(images,ndim)
                break
            packing+=0.001
            itercol+=1

        if (i+1)%100==0:
            print('grain ',i+1,' / ',car,'     ||   iters ',itercol,'pack',packing)
    #            break
    print('grain ',i+1,' / ',car,'     ||   iters ',itercol,'pack',packing)
    
    
             
    lol2=np.where(collocation==2)[0]
    
    grid=np.array(np.meshgrid(np.arange(n[0])*L[0]/n[0]+L[0]/n[0]/2,\
             np.arange(n[1])*L[1]/n[1]+L[1]/n[1]/2,\
             np.arange(n[2])*L[2]/n[2]+L[2]/n[2]/2)).transpose(2,1,3,0)
    
    grid=grid.reshape(n[0]*n[1]*n[2],ndim)
    
    def inside(i):
        diff2=grid[i]-xc
        distances2=np.sqrt(np.einsum('xi,xi->x',diff2,diff2))
        two=distances2/rr
        twoi=np.argmin(two)
        return lol2[twoi]//images+1
    
    print('shapes',np.shape(grid),np.shape(xc))
    prop=map(inside,range(ntot))
    prop=np.array(list(prop))
    print('npshapeprop',np.shape(prop))
    
    import pyevtk
    grid=grid.reshape(n[0],n[1],n[2],ndim)
    pointdat={}
    pointdat.update({'prop' : np.ascontiguousarray(prop.reshape(n[0],n[1],n[2]))})
    pyevtk.hl.gridToVTK(name,np.ascontiguousarray(grid[:,0,0,0]),\
     np.ascontiguousarray(grid[0,:,0,1]),np.ascontiguousarray(grid[0,0,:,2]),pointData=pointdat)
    
 #output summary and voexlized

    write_dx(L,n,prop,name)

    return prop

def write_dx(L,n,prop,filename):
    prop=prop.reshape(n)
    ff=open(filename+'.dx','w')
    ff.write('%f %f %f %d %d %d\n' % (L[0],L[1],L[2],n[0],n[1],n[2]))
    for nz in range(n[2]):
        for ny in range(n[1]):
            for nx in range(n[0]):
                ff.write('%d ' % (prop[nx,ny,nz]))
                if nx==n[0]-1:
                    ff.write('\n')
    ff.close()
    return